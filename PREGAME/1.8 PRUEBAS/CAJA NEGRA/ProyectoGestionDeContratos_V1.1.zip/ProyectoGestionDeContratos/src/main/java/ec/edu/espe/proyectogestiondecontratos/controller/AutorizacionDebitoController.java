package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.AutorizacionDebitoModel;
import ec.edu.espe.proyectogestiondecontratos.model.GestorContratos;
import ec.edu.espe.proyectogestiondecontratos.utils.Validador;
import ec.edu.espe.proyectogestiondecontratos.view.AutorizacionDebitoView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class AutorizacionDebitoController implements ActionListener {

    private AutorizacionDebitoView view;
    private AutorizacionDebitoModel model;
    private boolean esEdicion = false;

    // Constructor Crear
    public AutorizacionDebitoController(AutorizacionDebitoView view) {
        this.view = view;
        this.model = new AutorizacionDebitoModel();
        this.esEdicion = false;
        generarId();
        inicializar();
    }

    // Constructor Editar
    public AutorizacionDebitoController(AutorizacionDebitoView view, AutorizacionDebitoModel modeloExistente) {
        this.view = view;
        this.model = modeloExistente;
        this.esEdicion = true;
        
        view.setId(model.getId());
        view.setCiudad(model.getCiudad());
        view.setFecha(model.getFecha());
        view.setNombre(model.getNombre());
        view.setTipoCuenta(model.getTipoCuenta());
        view.setNumeroCuenta(model.getNumeroCuenta());
        view.setBanco(model.getBanco());
        view.setMonto(String.valueOf(model.getMontoMensual()));
        view.setCedula(model.getCedula());
        
        view.getBtnGuardar().setText("Actualizar Autorización");
        inicializar();
    }

    private void inicializar() {
        this.view.getBtnGuardar().addActionListener(this);
        this.view.getBtnCancelar().addActionListener(this);
    }

    private void generarId() {
        if (!esEdicion) {
            int num = (int)(Math.random() * 90000) + 10000;
            String id = "ADM-" + num; // ADM = Autorización Débito Mensual
            model.setId(id);
            view.setId(id);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnGuardar()) {
            guardar();
        } else if (e.getSource() == view.getBtnCancelar()) {
            view.cerrar();
        }
    }

    private void guardar() {
        String nombre = view.getNombre().trim();
        String cuenta = view.getNumeroCuenta().trim();
        String banco = view.getBanco().trim();
        String montoStr = view.getMonto().trim();
        String cedula = view.getCedula().trim();

        // Validaciones
        if (nombre.isEmpty() || cuenta.isEmpty() || banco.isEmpty() || cedula.isEmpty()) {
            view.mostrarMensaje("Por favor llene todos los campos.");
            return;
        }
        if (!Validador.esSoloNumeros(cuenta)) {
            view.mostrarMensaje("El número de cuenta debe ser numérico.");
            return;
        }
        if (!Validador.esMontoValido(montoStr)) {
            view.mostrarMensaje("Ingrese un monto mensual válido.");
            return;
        }
        if (!Validador.esCedulaValida(cedula)) {
            view.mostrarMensaje("Cédula inválida.");
            return;
        }

        // Guardar
        model.setCiudad(view.getCiudad());
        model.setFecha(view.getFecha());
        model.setNombre(nombre);
        model.setTipoCuenta(view.getTipoCuenta());
        model.setNumeroCuenta(cuenta);
        model.setBanco(banco);
        model.setMontoMensual(Double.parseDouble(montoStr));
        model.setCedula(cedula);

        if (!esEdicion) {
            GestorContratos.getInstancia().agregarContrato(model);
        }
        
        view.mostrarMensaje("Autorización de Débito registrada con éxito.");
        view.cerrar();
    }
}