package ec.edu.espe.proyectogestiondecontratos.utils; // O .controller si no creaste el paquete

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Validador {

    // 1. VALIDAR SOLO NÚMEROS (Para cuentas bancarias)
    public static boolean esSoloNumeros(String texto) {
        // Verifica que contenga solo dígitos del 0 al 9
        return texto != null && texto.matches("[0-9]+");
    }

    // 2. VALIDAR FORMATO DE CORREO (Regex estándar)
    public static boolean esCorreoValido(String correo) {
        if (correo == null || correo.isEmpty()) return false;
        
        // Patrón básico: texto @ texto . texto
        String regex = "^[\\w-\\.]+@([\\w-]+\\.)+[\\w-]{2,4}$";
        Pattern pattern = Pattern.compile(regex);
        Matcher matcher = pattern.matcher(correo);
        return matcher.matches();
    }

    // 3. VALIDAR MONTO (Que sea un número decimal positivo)
    public static boolean esMontoValido(String texto) {
        try {
            double valor = Double.parseDouble(texto);
            return valor > 0; // No aceptamos 0 ni negativos
        } catch (NumberFormatException e) {
            return false;
        }
    }

    // 4. VALIDAR CÉDULA ECUATORIANA (Algoritmo Módulo 10)
    public static boolean esCedulaValida(String cedula) {
        if (cedula == null || cedula.length() != 10 || !esSoloNumeros(cedula)) {
            return false;
        }

        try {
            int provincia = Integer.parseInt(cedula.substring(0, 2));
            int tercerDigito = Integer.parseInt(cedula.substring(2, 3));

            // Regla: Provincia entre 1 y 24 (o 30 para extranjeros), 3er dígito < 6
            if (provincia < 1 || provincia > 24 || tercerDigito >= 6) {
                return false;
            }

            // Algoritmo de validación del último dígito
            int[] coeficientes = {2, 1, 2, 1, 2, 1, 2, 1, 2};
            int suma = 0;

            for (int i = 0; i < coeficientes.length; i++) {
                int valor = Character.getNumericValue(cedula.charAt(i)) * coeficientes[i];
                if (valor >= 10) {
                    valor -= 9;
                }
                suma += valor;
            }

            int residuo = suma % 10;
            int digitoVerificadorCalculado = (residuo == 0) ? 0 : 10 - residuo;
            int digitoVerificadorReal = Character.getNumericValue(cedula.charAt(9));

            return digitoVerificadorCalculado == digitoVerificadorReal;

        } catch (NumberFormatException e) {
            return false;
        }
    }
}