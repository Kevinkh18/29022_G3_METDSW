package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import java.awt.*;

public class CambiarCredencialesView extends JDialog {
    
    private JTextField txtUsuario;
    private JPasswordField txtPassActual;
    private JPasswordField txtPassNueva;
    private JPasswordField txtPassConfirmacion;
    
    private JButton btnCambiarUsuario;
    private JButton btnCambiarPass;
    private JButton btnRegresar;

    public CambiarCredencialesView(Frame owner) {
        super(owner, "Configuración de Usuario", true);
        setSize(700, 450); // Un poco más ancho para asegurar espacio
        setLocationRelativeTo(owner);
        setResizable(false);
        configurarComponentes();
    }

    private void configurarComponentes() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 40, 20, 40));
        
        GridBagConstraints gbc = new GridBagConstraints();
        
        // Definir insets (márgenes) estándar
        Insets margenLabel = new Insets(10, 0, 10, 15);
        Insets margenCampo = new Insets(10, 0, 10, 0);
        Insets margenBoton = new Insets(10, 15, 10, 0);

        // --- TÍTULO ---
        JLabel lblTitulo = new JLabel("Datos y Herramientas de Usuario");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 20));
        lblTitulo.setForeground(new Color(50, 50, 70));
        
        gbc.gridx = 0; gbc.gridy = 0; 
        gbc.gridwidth = 3; 
        gbc.weightx = 0.0; // El título no necesita estirarse
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(0, 0, 30, 0);
        panel.add(lblTitulo, gbc);

        // ==================== FILA 1: USUARIO ====================
        
        // 1. Etiqueta (Sin estiramiento)
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1;
        gbc.weightx = 0.0; // Fijo
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = margenLabel;
        panel.add(crearEtiqueta("Usuario Login:"), gbc);
        
        // 2. Campo de Texto (CON ESTIRAMIENTO)
        txtUsuario = new JTextField(20); 
        gbc.gridx = 1; gbc.gridy = 1;
        gbc.weightx = 1.0; // <--- ¡LA SOLUCIÓN! (Ocupa todo el ancho disponible)
        gbc.fill = GridBagConstraints.HORIZONTAL; // Estírate horizontalmente
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = margenCampo;
        panel.add(txtUsuario, gbc);
        
        // 3. Botón (Sin estiramiento)
        btnCambiarUsuario = new JButton("Cambiar Usuario");
        estilizarBotonAccion(btnCambiarUsuario);
        gbc.gridx = 2; gbc.gridy = 1;
        gbc.weightx = 0.0; // Fijo, no se estira
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = margenBoton;
        panel.add(btnCambiarUsuario, gbc);

        // ==================== SEPARADOR ====================
        gbc.gridx = 0; gbc.gridy = 2; gbc.gridwidth = 3;
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(15, 0, 15, 0);
        panel.add(new JSeparator(), gbc);

        // ==================== FILA 3: PASS ACTUAL ====================
        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 1;
        gbc.weightx = 0.0;
        gbc.fill = GridBagConstraints.NONE; // Resetear fill
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = margenLabel;
        panel.add(crearEtiqueta("Contraseña actual:"), gbc);

        txtPassActual = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 3;
        gbc.weightx = 1.0; // <--- ¡LA SOLUCIÓN!
        gbc.fill = GridBagConstraints.HORIZONTAL; // Estírate
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = margenCampo;
        panel.add(txtPassActual, gbc);
        
        // Hueco vacío en la columna del botón
        gbc.gridx = 2; gbc.gridy = 3; 
        gbc.weightx = 0.0;
        panel.add(Box.createGlue(), gbc);

        // ==================== FILA 4: PASS NUEVA ====================
        gbc.gridx = 0; gbc.gridy = 4;
        gbc.weightx = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = margenLabel;
        panel.add(crearEtiqueta("Contraseña Nueva:"), gbc);

        txtPassNueva = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 4;
        gbc.weightx = 1.0; // <--- ¡LA SOLUCIÓN!
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = margenCampo;
        panel.add(txtPassNueva, gbc);

        btnCambiarPass = new JButton("Cambiar Contraseña");
        estilizarBotonAccion(btnCambiarPass);
        gbc.gridx = 2; gbc.gridy = 4;
        gbc.weightx = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = margenBoton;
        panel.add(btnCambiarPass, gbc);

        // ==================== FILA 5: CONFIRMACIÓN ====================
        gbc.gridx = 0; gbc.gridy = 5;
        gbc.weightx = 0.0;
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.EAST;
        gbc.insets = margenLabel;
        panel.add(crearEtiqueta("Confirmar Contraseña:"), gbc);

        txtPassConfirmacion = new JPasswordField(20);
        gbc.gridx = 1; gbc.gridy = 5;
        gbc.weightx = 1.0; // <--- ¡LA SOLUCIÓN!
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.anchor = GridBagConstraints.WEST;
        gbc.insets = margenCampo;
        panel.add(txtPassConfirmacion, gbc);

        // ==================== BOTÓN REGRESAR ====================
        btnRegresar = new JButton("Regresar");
        btnRegresar.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        btnRegresar.setBackground(Color.WHITE);
        btnRegresar.setFocusPainted(false);
        // Hacemos el botón un poco más ancho manualmente
        btnRegresar.setPreferredSize(new Dimension(150, 35)); 
        
        gbc.gridx = 0; gbc.gridy = 6; 
        gbc.gridwidth = 3;
        gbc.weightx = 1.0; // Para centrarlo bien
        gbc.fill = GridBagConstraints.NONE;
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(40, 0, 0, 0); 
        
        panel.add(btnRegresar, gbc);

        add(panel);
    }
    
    // --- Mismos métodos auxiliares y Getters ---
    private JLabel crearEtiqueta(String texto) {
        JLabel lbl = new JLabel(texto);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lbl.setForeground(new Color(80, 80, 80));
        return lbl;
    }
    
    private void estilizarBotonAccion(JButton btn) {
        btn.setBackground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200)),
                BorderFactory.createEmptyBorder(5, 15, 5, 15)
        ));
    }

    public String getUsuarioInput() { return txtUsuario.getText(); }
    public void setUsuarioInput(String texto) { txtUsuario.setText(texto); }
    public char[] getPassActual() { return txtPassActual.getPassword(); }
    public char[] getPassNueva() { return txtPassNueva.getPassword(); }
    public char[] getPassConfirmacion() { return txtPassConfirmacion.getPassword(); }
    public void limpiarCamposPass() {
        txtPassActual.setText("");
        txtPassNueva.setText("");
        txtPassConfirmacion.setText("");
    }
    public JButton getBtnCambiarUsuario() { return btnCambiarUsuario; }
    public JButton getBtnCambiarPass() { return btnCambiarPass; }
    public JButton getBtnRegresar() { return btnRegresar; }
}