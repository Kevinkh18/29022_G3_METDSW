package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import java.awt.*;

public class DashboardView extends VentanaBase {

    // Botones del CRUD
    private JButton btnCrear;
    private JButton btnLeer;     // Buscar/Listar
    private JButton btnActualizar;
    private JButton btnEliminar;

    // Botón de configuración (abajo)
    private JButton btnCambiarCredenciales;

    public DashboardView() {
        super("Sistema de Gestión de Fideicomisos"); // Título actualizado
        setSize(600, 500); // Un poco más grande para el menú
        configurarComponentes();
    }
    
    @Override
    protected void configurarComponentes() {
        setLayout(new BorderLayout());

        // --- 1. Encabezado (Título del Menú) ---
        JPanel panelHeader = new JPanel();
        panelHeader.setBackground(new Color(0, 51, 102)); // Azul oscuro corporativo
        panelHeader.setPreferredSize(new Dimension(getWidth(), 60));
        
        JLabel lblTitulo = new JLabel("MENÚ PRINCIPAL DE FIDEICOMISOS");
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        panelHeader.add(lblTitulo);
        
        add(panelHeader, BorderLayout.NORTH);

        // --- 2. Panel Central (Botones CRUD) ---
        JPanel panelMenu = new JPanel(new GridLayout(2, 2, 20, 20)); // 2 filas, 2 columnas, espacio de 20px
        panelMenu.setBorder(BorderFactory.createEmptyBorder(40, 40, 40, 40)); // Márgenes externos
        panelMenu.setBackground(new Color(245, 245, 245));

        // Creación de botones estilizados
        btnCrear = crearBotonMenu("Registrar Nuevo Fideicomiso", new Color(40, 167, 69)); // Verde
        btnLeer = crearBotonMenu("Ver / Buscar Contratos", new Color(23, 162, 184));      // Cyan/Azul
        btnActualizar = crearBotonMenu("Modificar Contrato", new Color(255, 193, 7));     // Amarillo/Naranja
        btnEliminar = crearBotonMenu("Dar de Baja / Eliminar", new Color(220, 53, 69));   // Rojo

        // Añadir al panel
        panelMenu.add(btnCrear);
        panelMenu.add(btnLeer);
        panelMenu.add(btnActualizar);
        panelMenu.add(btnEliminar);

        add(panelMenu, BorderLayout.CENTER);

        // --- 3. Panel Inferior (Configuración) ---
        JPanel panelInferior = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelInferior.setBackground(Color.LIGHT_GRAY);
        
        btnCambiarCredenciales = new JButton("Configurar Usuario y Contraseña");
        // Estilo simple para el botón secundario
        btnCambiarCredenciales.setBackground(Color.DARK_GRAY);
        btnCambiarCredenciales.setForeground(Color.WHITE);
        
        panelInferior.add(btnCambiarCredenciales);
        add(panelInferior, BorderLayout.SOUTH);
    }

    // Método auxiliar para crear botones uniformes (DRY - Don't Repeat Yourself)
    private JButton crearBotonMenu(String texto, Color colorFondo) {
        JButton btn = new JButton(texto);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(colorFondo);
        btn.setForeground(Color.WHITE); // Texto blanco
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createLineBorder(colorFondo.darker(), 2));
        return btn;
    }

    // Getters
    public JButton getBtnCrear() { return btnCrear; }
    public JButton getBtnLeer() { return btnLeer; }
    public JButton getBtnActualizar() { return btnActualizar; }
    public JButton getBtnEliminar() { return btnEliminar; }
    public JButton getBtnCambiarCredenciales() { return btnCambiarCredenciales; }
}