package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SolicitudDesvinculacionView extends JDialog {

    private JTextField txtId;
    private JTextField txtCiudad;
    private JTextField txtFecha;
    
    // Datos Bancarios
    private JTextField txtBanco;
    private JTextField txtNumeroCuenta;
    private JComboBox<String> cmbTipoCuenta;
    
    // Aunque el doc no lo pide escrito, el sistema lo necesita
    private JTextField txtMonto; 
    
    // Datos Personales (Footer)
    private JTextField txtNombre;
    private JTextField txtCedula;
    private JTextField txtCelular;
    private JTextField txtCorreo;

    private JButton btnGuardar;
    private JButton btnCancelar;

    public SolicitudDesvinculacionView(Frame owner) {
        super(owner, "Desvinculación y Rescate Total", true);
        setSize(500, 720);
        setLocationRelativeTo(owner);
        setResizable(false);
        configurarComponentes();
    }

    private void configurarComponentes() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 245));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(6, 6, 6, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // --- TÍTULO ---
        JLabel lblTitulo = new JLabel("SOLICITUD DE DESVINCULACIÓN TOTAL");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblTitulo.setForeground(new Color(150, 0, 0)); // Rojo oscuro para indicar seriedad
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);

        gbc.gridwidth = 1; 

        // --- ID ---
        txtId = crearCampoNoEditable();
        agregarCampo(panel, gbc, 1, "ID Trámite:", txtId);

        // --- FECHA Y LUGAR ---
        addSeparator(panel, gbc, 2, "Lugar y Fecha");
        txtCiudad = new JTextField("Quito");
        agregarCampo(panel, gbc, 3, "Ciudad:", txtCiudad);
        txtFecha = new JTextField(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        agregarCampo(panel, gbc, 4, "Fecha:", txtFecha);

        // --- TEXTO LEGAL ---
        gbc.gridx = 0; gbc.gridy = 5; gbc.gridwidth = 2;
        JTextArea lblLegal = new JTextArea("Por medio de la presente solicito mi DESVINCULACIÓN voluntaria del Fideicomiso y la restitución total de mis aportes y rendimientos.");
        lblLegal.setLineWrap(true);
        lblLegal.setWrapStyleWord(true);
        lblLegal.setEditable(false);
        lblLegal.setBackground(null);
        lblLegal.setFont(new Font("Segoe UI", Font.ITALIC, 11));
        lblLegal.setBorder(BorderFactory.createEmptyBorder(10, 5, 10, 5));
        panel.add(lblLegal, gbc);
        gbc.gridwidth = 1;

        // --- DATOS BANCARIOS ---
        addSeparator(panel, gbc, 6, "Cuenta para Transferencia");
        
        txtBanco = new JTextField(15);
        agregarCampo(panel, gbc, 7, "Banco:", txtBanco);
        
        txtNumeroCuenta = new JTextField(15);
        agregarCampo(panel, gbc, 8, "Número de Cuenta:", txtNumeroCuenta);
        
        cmbTipoCuenta = new JComboBox<>(new String[]{"Ahorros", "Corriente"});
        gbc.gridx = 0; gbc.gridy = 9; panel.add(new JLabel("Tipo de Cuenta:"), gbc);
        gbc.gridx = 1; gbc.gridy = 9; panel.add(cmbTipoCuenta, gbc);

        // --- MONTO (SISTEMA) ---
        addSeparator(panel, gbc, 10, "Registro Interno");
        txtMonto = new JTextField(15);
        // Explicación visual
        txtMonto.setToolTipText("Ingrese el valor total acumulado para registro en el sistema");
        agregarCampo(panel, gbc, 11, "Monto Total Estimado ($):", txtMonto);

        // --- DATOS PERSONALES ---
        addSeparator(panel, gbc, 12, "Datos del Constituyente");
        
        txtNombre = new JTextField(15);
        agregarCampo(panel, gbc, 13, "Nombre Completo:", txtNombre);
        
        txtCedula = new JTextField(15);
        agregarCampo(panel, gbc, 14, "Cédula (C.C.):", txtCedula);
        
        txtCelular = new JTextField(15);
        agregarCampo(panel, gbc, 15, "Teléfono Celular:", txtCelular);
        
        txtCorreo = new JTextField(15);
        agregarCampo(panel, gbc, 16, "Correo Electrónico:", txtCorreo);

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnGuardar = new JButton("Procesar Desvinculación");
        btnGuardar.setBackground(new Color(220, 53, 69)); // Rojo (Acción crítica)
        btnGuardar.setForeground(Color.WHITE);
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBackground(Color.GRAY);
        btnCancelar.setForeground(Color.WHITE);

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        gbc.gridx = 0; gbc.gridy = 17; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        panel.add(panelBotones, gbc);
        
        aplicarMenuContextual();
        add(panel);
    }

    // --- MÉTODOS AUXILIARES ---
    private void agregarCampo(JPanel p, GridBagConstraints g, int y, String label, JComponent campo) {
        g.gridx = 0; g.gridy = y;
        JLabel lbl = new JLabel(label);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(lbl, g);
        g.gridx = 1; g.gridy = y;
        p.add(campo, g);
    }
    
    private void addSeparator(JPanel p, GridBagConstraints g, int y, String titulo) {
        g.gridx = 0; g.gridy = y; g.gridwidth = 2;
        JLabel lbl = new JLabel(titulo);
        lbl.setFont(new Font("Segoe UI", Font.BOLD, 12));
        lbl.setForeground(new Color(0, 51, 102));
        lbl.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY));
        p.add(lbl, g);
        g.gridwidth = 1; 
    }

    private JTextField crearCampoNoEditable() {
        JTextField txt = new JTextField(20);
        txt.setEditable(false);
        txt.setBackground(new Color(230, 230, 230));
        txt.setFont(new Font("Monospaced", Font.BOLD, 12));
        return txt;
    }
    
    private void aplicarMenuContextual() {
        agregarMenu(txtId, false);
        agregarMenu(txtCiudad, true);
        agregarMenu(txtBanco, true);
        agregarMenu(txtNumeroCuenta, true);
        agregarMenu(txtMonto, true);
        agregarMenu(txtNombre, true);
        agregarMenu(txtCedula, true);
        agregarMenu(txtCelular, true);
        agregarMenu(txtCorreo, true);
    }
    
    private void agregarMenu(JTextField campo, boolean editable) {
        JPopupMenu menu = new JPopupMenu();
        JMenuItem itemCopiar = new JMenuItem("Copiar");
        itemCopiar.addActionListener(e -> campo.copy());
        menu.add(itemCopiar);
        if (editable) {
            JMenuItem itemPegar = new JMenuItem("Pegar");
            itemPegar.addActionListener(e -> campo.paste());
            menu.add(itemPegar);
        }
        campo.setComponentPopupMenu(menu);
    }

    // --- GETTERS Y SETTERS ---
    public void setId(String t) { txtId.setText(t); }
    public String getCiudad() { return txtCiudad.getText(); }
    public void setCiudad(String t) { txtCiudad.setText(t); }
    
    public String getFecha() { return txtFecha.getText(); }
    public void setFecha(String t) { txtFecha.setText(t); }

    public String getBanco() { return txtBanco.getText(); }
    public void setBanco(String t) { txtBanco.setText(t); }

    public String getNumeroCuenta() { return txtNumeroCuenta.getText(); }
    public void setNumeroCuenta(String t) { txtNumeroCuenta.setText(t); }

    public String getTipoCuenta() { return (String) cmbTipoCuenta.getSelectedItem(); }
    public void setTipoCuenta(String t) { cmbTipoCuenta.setSelectedItem(t); }

    public String getMonto() { return txtMonto.getText(); }
    public void setMonto(String t) { txtMonto.setText(t); }

    public String getNombre() { return txtNombre.getText(); }
    public void setNombre(String t) { txtNombre.setText(t); }

    public String getCedula() { return txtCedula.getText(); }
    public void setCedula(String t) { txtCedula.setText(t); }

    public String getCelular() { return txtCelular.getText(); }
    public void setCelular(String t) { txtCelular.setText(t); }

    public String getCorreo() { return txtCorreo.getText(); }
    public void setCorreo(String t) { txtCorreo.setText(t); }

    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnCancelar() { return btnCancelar; }
    public void cerrar() { dispose(); }
    public void mostrarMensaje(String m) { JOptionPane.showMessageDialog(this, m); }
}