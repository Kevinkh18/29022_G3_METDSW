package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import javax.swing.text.JTextComponent; // Importante para manejar cualquier campo de texto
import java.awt.*;

public class SolicitudRescateView extends JDialog {

    private JTextField txtId;
    
    private JTextField txtNombre;
    private JTextField txtBanco;
    private JTextField txtCuenta;
    private JComboBox<String> cmbTipoCuenta;
    private JTextField txtCedula;
    private JTextField txtValor;
    private JTextField txtCorreo;

    private JButton btnGuardar;
    private JButton btnCancelar;

    public SolicitudRescateView(Frame owner) {
        super(owner, "Solicitud de Rescate Parcial", true);
        setSize(450, 600); 
        setLocationRelativeTo(owner);
        setResizable(false);
        configurarComponentes();
    }

    private void configurarComponentes() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        JLabel lblTitulo = new JLabel("Formulario de Restitución de Valores");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 16));
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);

        gbc.gridwidth = 1;

        // --- CAMPO ID (SOLO LECTURA) ---
        txtId = new JTextField(20);
        txtId.setEditable(false); 
        txtId.setBackground(Color.LIGHT_GRAY); 
        txtId.setFont(new Font("Monospaced", Font.BOLD, 12)); 
        
        // ¡MAGIA AQUÍ! Agregamos el menú al ID
        agregarMenuContextual(txtId);

        agregarCampo(panel, gbc, 1, "ID Solicitud (Auto):", txtId);

        // --- INICIALIZACIÓN DE LOS DEMÁS CAMPOS ---
        txtNombre = new JTextField(20);
        txtBanco = new JTextField(20);
        txtCuenta = new JTextField(20);
        txtCedula = new JTextField(20);
        txtValor = new JTextField(20);
        txtCorreo = new JTextField(20);

        // ¡MAGIA AQUÍ! Agregamos el menú a TODOS los campos
        agregarMenuContextual(txtNombre);
        agregarMenuContextual(txtBanco);
        agregarMenuContextual(txtCuenta);
        agregarMenuContextual(txtCedula);
        agregarMenuContextual(txtValor);
        agregarMenuContextual(txtCorreo);

        // --- AÑADIRLOS AL PANEL ---
        agregarCampo(panel, gbc, 2, "Nombre Beneficiario:", txtNombre);
        agregarCampo(panel, gbc, 3, "Banco de Acreditación:", txtBanco);
        agregarCampo(panel, gbc, 4, "Número de Cuenta:", txtCuenta);
        
        cmbTipoCuenta = new JComboBox<>(new String[]{"Ahorro", "Corriente"});
        gbc.gridx = 0; gbc.gridy = 5; panel.add(new JLabel("Tipo de Cuenta:"), gbc);
        gbc.gridx = 1; gbc.gridy = 5; panel.add(cmbTipoCuenta, gbc);

        agregarCampo(panel, gbc, 6, "Cédula o RUC:", txtCedula);
        agregarCampo(panel, gbc, 7, "Valor a Restituir ($):", txtValor);
        agregarCampo(panel, gbc, 8, "Correo Electrónico:", txtCorreo);

        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        btnGuardar = new JButton("Enviar Solicitud");
        btnGuardar.setBackground(new Color(40, 167, 69));
        btnGuardar.setForeground(Color.WHITE);
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBackground(new Color(220, 53, 69));
        btnCancelar.setForeground(Color.WHITE);

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        gbc.gridx = 0; gbc.gridy = 9; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        panel.add(panelBotones, gbc);

        add(panel);
    }

    private void agregarCampo(JPanel p, GridBagConstraints g, int y, String label, JComponent campo) {
        g.gridx = 0; g.gridy = y;
        p.add(new JLabel(label), g);
        g.gridx = 1; g.gridy = y;
        p.add(campo, g);
    }

    // =====================================================================
    // --- MÉTODO PARA AGREGAR CLICK DERECHO (COPIAR/PEGAR) A CUALQUIER CAMPO ---
    // =====================================================================
    private void agregarMenuContextual(JTextComponent campo) {
        JPopupMenu menu = new JPopupMenu();

        // Opción Copiar
        JMenuItem itemCopiar = new JMenuItem("Copiar");
        itemCopiar.addActionListener(e -> campo.copy());
        menu.add(itemCopiar);

        // Si el campo es editable (como nombre, banco...), agregamos Cortar y Pegar
        if (campo.isEditable()) {
            JMenuItem itemCortar = new JMenuItem("Cortar");
            itemCortar.addActionListener(e -> campo.cut());
            menu.add(itemCortar);

            JMenuItem itemPegar = new JMenuItem("Pegar");
            itemPegar.addActionListener(e -> campo.paste());
            menu.add(itemPegar);
        }

        campo.setComponentPopupMenu(menu);
    }
    // =====================================================================

    // --- MÉTODOS DE ACCESO (Sin cambios) ---
    public void setId(String id) { txtId.setText(id); }
    public String getNombre() { return txtNombre.getText(); }
    public String getBanco() { return txtBanco.getText(); }
    public String getCuenta() { return txtCuenta.getText(); }
    public String getTipoCuenta() { return (String) cmbTipoCuenta.getSelectedItem(); }
    public String getCedula() { return txtCedula.getText(); }
    public String getValor() { return txtValor.getText(); }
    public String getCorreo() { return txtCorreo.getText(); }
    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnCancelar() { return btnCancelar; }
    public void cerrar() { this.dispose(); }
    public void mostrarMensaje(String msg) { JOptionPane.showMessageDialog(this, msg); }
    
    public void setNombre(String t) { txtNombre.setText(t); }
    public void setBanco(String t) { txtBanco.setText(t); }
    public void setCuenta(String t) { txtCuenta.setText(t); }
    public void setCedula(String t) { txtCedula.setText(t); }
    public void setValor(String t) { txtValor.setText(t); }
    public void setCorreo(String t) { txtCorreo.setText(t); }
    public void setTipoCuenta(String t) { cmbTipoCuenta.setSelectedItem(t); }
    
    public void setTituloVentana(String titulo) { setTitle(titulo); }
}