package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import java.awt.*;

public class SeleccionTipoFideicomisoView extends JDialog {

    // Definimos los 4 botones según tu imagen de archivos
    private JButton btnRescateParcial;      // Para "Solicitud rescate parcial"
    private JButton btnRescateTotal;        // Para "SOLICITUD DESVINCULACIÓN Y RESCATE TOTAL"
    private JButton btnDebitoMensual;       // Para "AUTORIZACION DE DEBITO MENSUAL"
    private JButton btnRescateGenerico;     // Para "Solicitud de Rescate" (El Excel)
    
    private JButton btnCancelar;

    public SeleccionTipoFideicomisoView(Frame owner) {
        super(owner, "Selección de Trámite", true);
        setSize(550, 500); // Un poco más alto para que quepan los 4 botones
        setLocationRelativeTo(owner);
        setResizable(false);
        configurarComponentes();
    }

    private void configurarComponentes() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(245, 245, 250));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 10, 8, 10); // Espaciado entre botones
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;

        // --- Título ---
        JLabel lblTitulo = new JLabel("Seleccione el Tipo de Documento");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(new Color(50, 50, 70));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        
        gbc.gridy = 0;
        panel.add(lblTitulo, gbc);
        
        gbc.gridy = 1;
        panel.add(new JSeparator(), gbc);

        // --- BOTÓN 1: RESCATE PARCIAL (El que ya programamos) ---
        btnRescateParcial = crearBotonOpcion("Solicitud de Rescate Parcial", "Restitución parcial de valores");
        gbc.gridy = 2;
        panel.add(btnRescateParcial, gbc);

        // --- BOTÓN 2: RESCATE TOTAL Y DESVINCULACIÓN ---
        btnRescateTotal = crearBotonOpcion("Desvinculación y Rescate Total", "Retiro total de fondos y cierre");
        gbc.gridy = 3;
        panel.add(btnRescateTotal, gbc);

        // --- BOTÓN 3: DÉBITO MENSUAL ---
        btnDebitoMensual = crearBotonOpcion("Autorización de Débito Mensual", "Configuración de aportes automáticos");
        gbc.gridy = 4;
        panel.add(btnDebitoMensual, gbc);

        // --- BOTÓN 4: SOLICITUD DE RESCATE (GENÉRICA/EXCEL) ---
        btnRescateGenerico = crearBotonOpcion("Solicitud de Rescate (Formato Excel)", "Formato estándar de solicitud");
        gbc.gridy = 5;
        panel.add(btnRescateGenerico, gbc);

        // --- Botón Cancelar ---
        btnCancelar = new JButton("Cancelar Operación");
        btnCancelar.setBackground(new Color(220, 53, 69));
        btnCancelar.setForeground(Color.WHITE);
        btnCancelar.setFont(new Font("Segoe UI", Font.BOLD, 12));
        btnCancelar.setFocusPainted(false);
        
        gbc.gridy = 6;
        gbc.fill = GridBagConstraints.NONE; 
        gbc.anchor = GridBagConstraints.CENTER;
        gbc.insets = new Insets(25, 0, 0, 0); // Más margen arriba
        panel.add(btnCancelar, gbc);

        add(panel);
    }

    private JButton crearBotonOpcion(String titulo, String subtitulo) {
        // Usamos HTML para poner título en negrita y subtítulo abajo
        String html = "<html><div style='text-align: center; width: 300px;'>" 
                    + "<span style='font-size:14px; font-weight:bold;'>" + titulo + "</span><br/>" 
                    + "<span style='font-size:10px; font-weight:normal; color:#555555;'>" + subtitulo + "</span>" 
                    + "</div></html>";
        
        JButton btn = new JButton(html);
        btn.setPreferredSize(new Dimension(380, 55)); // Botones anchos
        btn.setBackground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        
        // Efecto Hover simple (Opcional, se ve bonito)
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) { btn.setBackground(new Color(240, 248, 255)); }
            public void mouseExited(java.awt.event.MouseEvent evt) { btn.setBackground(Color.WHITE); }
        });

        return btn;
    }

    // --- GETTERS (Necesarios para el Controlador) ---
    public JButton getBtnRescateParcial() { return btnRescateParcial; }
    public JButton getBtnRescateTotal() { return btnRescateTotal; }
    public JButton getBtnDebitoMensual() { return btnDebitoMensual; }
    public JButton getBtnRescateGenerico() { return btnRescateGenerico; }
    public JButton getBtnCancelar() { return btnCancelar; }
}