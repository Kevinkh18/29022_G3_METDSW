package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import javax.swing.text.JTextComponent;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AutorizacionDebitoView extends JDialog {

    private JTextField txtId;
    private JTextField txtCiudad;
    private JTextField txtFecha;
    
    private JTextField txtNombre;
    private JComboBox<String> cmbTipoCuenta;
    private JTextField txtNumeroCuenta;
    private JTextField txtBanco;
    private JTextField txtMonto;
    private JTextField txtCedula;

    private JButton btnGuardar;
    private JButton btnCancelar;

    public AutorizacionDebitoView(Frame owner) {
        super(owner, "Autorización de Débito Automático", true);
        setSize(500, 650);
        setLocationRelativeTo(owner);
        setResizable(false);
        configurarComponentes();
    }

    private void configurarComponentes() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(40, 40, 40)); // Fondo oscuro como la imagen
        panel.setBorder(BorderFactory.createEmptyBorder(20, 30, 20, 30));
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        
        // --- TÍTULO ---
        JLabel lblTitulo = new JLabel("AUTORIZACIÓN DE DÉBITO");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setForeground(Color.WHITE);
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(lblTitulo, gbc);
        
        JLabel lblSub = new JLabel("FIDEICOMISO DE INVERSIÓN");
        lblSub.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblSub.setForeground(Color.LIGHT_GRAY);
        lblSub.setHorizontalAlignment(SwingConstants.CENTER);
        gbc.gridy = 1;
        panel.add(lblSub, gbc);

        gbc.gridwidth = 1; // Restaurar

        // --- ID ---
        txtId = crearCampo(false);
        agregarFila(panel, gbc, 2, "ID Trámite:", txtId);

        // --- FECHA ---
        txtCiudad = crearCampo(true);
        txtCiudad.setText("Quito");
        agregarFila(panel, gbc, 3, "Ciudad:", txtCiudad);
        
        txtFecha = crearCampo(true);
        txtFecha.setText(new SimpleDateFormat("dd/MM/yyyy").format(new Date()));
        agregarFila(panel, gbc, 4, "Fecha:", txtFecha);

        // --- SEPARADOR ---
        addSeparator(panel, gbc, 5);

        // --- DATOS DEL CLIENTE Y CUENTA ---
        txtNombre = crearCampo(true);
        agregarFila(panel, gbc, 6, "Yo, (Nombre Completo):", txtNombre);
        
        cmbTipoCuenta = new JComboBox<>(new String[]{"Ahorros", "Corriente"});
        gbc.gridx = 0; gbc.gridy = 7; 
        JLabel lblTipo = new JLabel("Tipo de Cuenta:");
        lblTipo.setForeground(Color.WHITE);
        panel.add(lblTipo, gbc);
        gbc.gridx = 1; 
        panel.add(cmbTipoCuenta, gbc);
        
        txtNumeroCuenta = crearCampo(true);
        agregarFila(panel, gbc, 8, "Número de Cuenta:", txtNumeroCuenta);
        
        txtBanco = crearCampo(true);
        agregarFila(panel, gbc, 9, "Institución Financiera:", txtBanco);

        // --- MONTO ---
        addSeparator(panel, gbc, 10);
        
        txtMonto = crearCampo(true);
        txtMonto.setFont(new Font("Segoe UI", Font.BOLD, 14));
        agregarFila(panel, gbc, 11, "Monto MENSUAL (USD):", txtMonto);
        
        txtCedula = crearCampo(true);
        agregarFila(panel, gbc, 12, "Cédula de Identidad (C.I.):", txtCedula);

        // --- BOTONES ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotones.setBackground(new Color(40, 40, 40));
        
        btnGuardar = new JButton("Autorizar Débito");
        btnGuardar.setBackground(new Color(0, 123, 255));
        btnGuardar.setForeground(Color.WHITE);
        
        btnCancelar = new JButton("Cancelar");
        btnCancelar.setBackground(Color.GRAY);
        btnCancelar.setForeground(Color.WHITE);

        panelBotones.add(btnCancelar);
        panelBotones.add(btnGuardar);

        gbc.gridx = 0; gbc.gridy = 13; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 5, 5, 5);
        panel.add(panelBotones, gbc);
        
        aplicarMenuContextual();
        add(panel);
    }

    private void agregarFila(JPanel p, GridBagConstraints g, int y, String label, JComponent campo) {
        g.gridx = 0; g.gridy = y;
        JLabel lbl = new JLabel(label);
        lbl.setForeground(Color.WHITE);
        lbl.setFont(new Font("Segoe UI", Font.PLAIN, 12));
        p.add(lbl, g);
        g.gridx = 1; g.gridy = y;
        p.add(campo, g);
    }
    
    private void addSeparator(JPanel p, GridBagConstraints g, int y) {
        g.gridx = 0; g.gridy = y; g.gridwidth = 2;
        p.add(new JSeparator(), g);
        g.gridwidth = 1; 
    }

    private JTextField crearCampo(boolean editable) {
        JTextField txt = new JTextField(15);
        txt.setEditable(editable);
        if (!editable) {
            txt.setBackground(Color.LIGHT_GRAY);
            txt.setForeground(Color.BLACK);
        }
        return txt;
    }
    
    private void aplicarMenuContextual() {
        agregarMenu(txtId, false);
        agregarMenu(txtCiudad, true);
        agregarMenu(txtNombre, true);
        agregarMenu(txtNumeroCuenta, true);
        agregarMenu(txtBanco, true);
        agregarMenu(txtMonto, true);
        agregarMenu(txtCedula, true);
    }
    
    private void agregarMenu(JTextField campo, boolean editable) {
        JPopupMenu menu = new JPopupMenu();
        JMenuItem itemCopiar = new JMenuItem("Copiar");
        itemCopiar.addActionListener(e -> campo.copy());
        menu.add(itemCopiar);
        if (editable) {
            JMenuItem itemPegar = new JMenuItem("Pegar");
            itemPegar.addActionListener(e -> campo.paste());
            menu.add(itemPegar);
        }
        campo.setComponentPopupMenu(menu);
    }

    // --- GETTERS Y SETTERS ---
    public void setId(String t) { txtId.setText(t); }
    public String getCiudad() { return txtCiudad.getText(); }
    public void setCiudad(String t) { txtCiudad.setText(t); }
    
    public String getFecha() { return txtFecha.getText(); }
    public void setFecha(String t) { txtFecha.setText(t); }

    public String getNombre() { return txtNombre.getText(); }
    public void setNombre(String t) { txtNombre.setText(t); }

    public String getTipoCuenta() { return (String) cmbTipoCuenta.getSelectedItem(); }
    public void setTipoCuenta(String t) { cmbTipoCuenta.setSelectedItem(t); }

    public String getNumeroCuenta() { return txtNumeroCuenta.getText(); }
    public void setNumeroCuenta(String t) { txtNumeroCuenta.setText(t); }

    public String getBanco() { return txtBanco.getText(); }
    public void setBanco(String t) { txtBanco.setText(t); }

    public String getMonto() { return txtMonto.getText(); }
    public void setMonto(String t) { txtMonto.setText(t); }

    public String getCedula() { return txtCedula.getText(); }
    public void setCedula(String t) { txtCedula.setText(t); }

    public JButton getBtnGuardar() { return btnGuardar; }
    public JButton getBtnCancelar() { return btnCancelar; }
    public void cerrar() { dispose(); }
    public void mostrarMensaje(String m) { JOptionPane.showMessageDialog(this, m); }
}