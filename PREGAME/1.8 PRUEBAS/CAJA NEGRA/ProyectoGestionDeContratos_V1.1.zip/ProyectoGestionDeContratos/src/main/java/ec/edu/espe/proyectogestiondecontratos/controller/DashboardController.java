package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.AutorizacionDebitoModel; // <--- NUEVO
import ec.edu.espe.proyectogestiondecontratos.model.ContratoBase;
import ec.edu.espe.proyectogestiondecontratos.model.GestorAutenticacion;
import ec.edu.espe.proyectogestiondecontratos.model.GestorContratos;
import ec.edu.espe.proyectogestiondecontratos.model.SolicitudDesvinculacionModel;
import ec.edu.espe.proyectogestiondecontratos.model.SolicitudRescateGenericoModel;
import ec.edu.espe.proyectogestiondecontratos.model.SolicitudRescateModel;
import ec.edu.espe.proyectogestiondecontratos.view.AutorizacionDebitoView; // <--- NUEVO
import ec.edu.espe.proyectogestiondecontratos.view.CambiarCredencialesView;
import ec.edu.espe.proyectogestiondecontratos.view.DashboardView;
import ec.edu.espe.proyectogestiondecontratos.view.ListaContratosView;
import ec.edu.espe.proyectogestiondecontratos.view.SeleccionTipoFideicomisoView;
import ec.edu.espe.proyectogestiondecontratos.view.SolicitudDesvinculacionView;
import ec.edu.espe.proyectogestiondecontratos.view.SolicitudRescateGenericoView;
import ec.edu.espe.proyectogestiondecontratos.view.SolicitudRescateView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class DashboardController implements ActionListener {

    private DashboardView view;

    public DashboardController(DashboardView view) {
        this.view = view;
        inicializarVista();
    }
    
    private void inicializarVista() {
        this.view.getBtnCrear().addActionListener(this);
        this.view.getBtnLeer().addActionListener(this);
        this.view.getBtnActualizar().addActionListener(this);
        this.view.getBtnEliminar().addActionListener(this);
        this.view.getBtnCambiarCredenciales().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnCrear()) {
            abrirSeleccionTipo(); 
        } 
        else if (e.getSource() == view.getBtnLeer()) {
            abrirListaContratos();
        } 
        
        // =====================================================================
        // --- 1. LÓGICA DE ACTUALIZAR / MODIFICAR ---
        // =====================================================================
        else if (e.getSource() == view.getBtnActualizar()) {
            
            String id = JOptionPane.showInputDialog(view, "Ingrese el ID del contrato a modificar:");
            
            if (id != null && !id.isEmpty()) {
                // A. Buscamos el contrato como GENÉRICO
                ContratoBase contratoEncontrado = GestorContratos.getInstancia().buscarContrato(id.trim());
                
                if (contratoEncontrado != null) {
                    
                    // B. DETECTAMOS QUÉ TIPO ES PARA ABRIR LA VENTANA CORRECTA
                    
                    if (contratoEncontrado instanceof SolicitudRescateModel) {
                        // TIPO 1: RESCATE PARCIAL (AZUL)
                        SolicitudRescateView viewEdicion = new SolicitudRescateView(view);
                        new SolicitudRescateController(viewEdicion, (SolicitudRescateModel) contratoEncontrado); 
                        viewEdicion.setVisible(true);
                        
                    } else if (contratoEncontrado instanceof SolicitudRescateGenericoModel) {
                        // TIPO 2: RESCATE EXCEL (BLANCO)
                        SolicitudRescateGenericoView viewEdicion = new SolicitudRescateGenericoView(view);
                        new SolicitudRescateGenericoController(viewEdicion, (SolicitudRescateGenericoModel) contratoEncontrado);
                        viewEdicion.setVisible(true);
                        
                    } else if (contratoEncontrado instanceof SolicitudDesvinculacionModel) {
                        // TIPO 3: DESVINCULACIÓN (ROJO)
                        SolicitudDesvinculacionView viewEdicion = new SolicitudDesvinculacionView(view);
                        new SolicitudDesvinculacionController(viewEdicion, (SolicitudDesvinculacionModel) contratoEncontrado);
                        viewEdicion.setVisible(true);
                        
                    } else if (contratoEncontrado instanceof AutorizacionDebitoModel) {
                        // TIPO 4: DÉBITO MENSUAL (OSCURO) <--- NUEVO
                        AutorizacionDebitoView viewEdicion = new AutorizacionDebitoView(view);
                        new AutorizacionDebitoController(viewEdicion, (AutorizacionDebitoModel) contratoEncontrado);
                        viewEdicion.setVisible(true);
                    }
                    
                } else {
                    JOptionPane.showMessageDialog(view, "No se encontró ningún contrato con el ID: " + id, "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } 
        
        // =====================================================================
        // --- 2. LÓGICA DE ELIMINAR ---
        // =====================================================================
        else if (e.getSource() == view.getBtnEliminar()) {
            
            String id = JOptionPane.showInputDialog(view, "Ingrese el ID del contrato a eliminar:");
            
            if (id != null && !id.isEmpty()) {
                ContratoBase contrato = GestorContratos.getInstancia().buscarContrato(id.trim());
                
                if (contrato != null) {
                    int confirmacion = JOptionPane.showConfirmDialog(view, 
                            "¿Está seguro de eliminar el contrato de " + contrato.getNombreCliente() + "?\nEsta acción no se puede deshacer.",
                            "Confirmar Eliminación", JOptionPane.YES_NO_OPTION);
                    
                    if (confirmacion == JOptionPane.YES_OPTION) {
                        GestorContratos.getInstancia().eliminarContrato(id.trim());
                        JOptionPane.showMessageDialog(view, "Contrato eliminado correctamente.");
                    }
                } else {
                    JOptionPane.showMessageDialog(view, "No se encontró el contrato.", "Error", JOptionPane.ERROR_MESSAGE);
                }
            }
        } 
        
        else if (e.getSource() == view.getBtnCambiarCredenciales()) {
            abrirCambioCredenciales();
        }
    }
    
    // --- MÉTODOS AUXILIARES ---
    
    private void abrirListaContratos() {
        ListaContratosView viewLista = new ListaContratosView(view);
        new ListaContratosController(viewLista);
        viewLista.setVisible(true);
    }

    private void abrirSeleccionTipo() {
        SeleccionTipoFideicomisoView dialogSeleccion = new SeleccionTipoFideicomisoView(view);

        // 1. Solicitud de Rescate Parcial (SRP)
        dialogSeleccion.getBtnRescateParcial().addActionListener(evt -> {
            dialogSeleccion.dispose(); 
            SolicitudRescateView viewRescate = new SolicitudRescateView(view); 
            new SolicitudRescateController(viewRescate); 
            viewRescate.setVisible(true);
        });

        // 2. Desvinculación y Rescate Total (SDT)
        dialogSeleccion.getBtnRescateTotal().addActionListener(evt -> {
            dialogSeleccion.dispose();
            SolicitudDesvinculacionView viewDesv = new SolicitudDesvinculacionView(view);
            new SolicitudDesvinculacionController(viewDesv);
            viewDesv.setVisible(true);
        });

        // 3. Débito Mensual (ADM) - YA IMPLEMENTADO
        dialogSeleccion.getBtnDebitoMensual().addActionListener(evt -> {
            dialogSeleccion.dispose();
            AutorizacionDebitoView viewDeb = new AutorizacionDebitoView(view);
            new AutorizacionDebitoController(viewDeb);
            viewDeb.setVisible(true);
        });
        
        // 4. Rescate Genérico / Excel (SRE)
        dialogSeleccion.getBtnRescateGenerico().addActionListener(evt -> {
            dialogSeleccion.dispose();
            SolicitudRescateGenericoView viewExcel = new SolicitudRescateGenericoView(view);
            new SolicitudRescateGenericoController(viewExcel);
            viewExcel.setVisible(true);
        });

        dialogSeleccion.getBtnCancelar().addActionListener(evt -> dialogSeleccion.dispose());
        dialogSeleccion.setVisible(true);
    }
    
    private void abrirCambioCredenciales() {
        CambiarCredencialesView dialog = new CambiarCredencialesView(view);
        GestorAutenticacion gestor = GestorAutenticacion.getInstancia();

        dialog.setUsuarioInput(gestor.getUsuarioActual());

        dialog.getBtnCambiarUsuario().addActionListener(evt -> {
            String nuevoUser = dialog.getUsuarioInput().trim();
            if (!nuevoUser.isEmpty()) {
                gestor.setUsuario(nuevoUser); 
                JOptionPane.showMessageDialog(dialog, "Usuario actualizado a: " + nuevoUser);
            } else {
                JOptionPane.showMessageDialog(dialog, "El usuario no puede estar vacío.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        dialog.getBtnCambiarPass().addActionListener(evt -> {
            String passActual = new String(dialog.getPassActual());
            String passNueva = new String(dialog.getPassNueva());
            String passConfirm = new String(dialog.getPassConfirmacion());

            if (!gestor.verificarContrasenaActual(passActual)) {
                JOptionPane.showMessageDialog(dialog, "Contraseña actual incorrecta.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (passNueva.length() < 8) {
                JOptionPane.showMessageDialog(dialog, "La contraseña debe tener mínimo 8 caracteres.", "Seguridad", JOptionPane.WARNING_MESSAGE);
                return;
            }
            if (!passNueva.equals(passConfirm)) {
                JOptionPane.showMessageDialog(dialog, "Las contraseñas no coinciden.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            gestor.setContrasena(passNueva);
            JOptionPane.showMessageDialog(dialog, "¡Contraseña actualizada con éxito!");
            dialog.limpiarCamposPass();
        });

        dialog.getBtnRegresar().addActionListener(evt -> dialog.dispose());
        dialog.setVisible(true);
    }
}