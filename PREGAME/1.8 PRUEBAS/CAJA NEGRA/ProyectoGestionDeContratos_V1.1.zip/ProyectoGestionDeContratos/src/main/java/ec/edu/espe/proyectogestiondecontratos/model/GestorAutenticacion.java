package ec.edu.espe.proyectogestiondecontratos.model;

public class GestorAutenticacion {
    
    private static GestorAutenticacion instancia;
    
    // Variables modificables para la sesión actual
    private String usuarioValido;
    private String contrasenaValida;

    private GestorAutenticacion() {
        // Datos iniciales
        this.usuarioValido = "admin";
        this.contrasenaValida = "12345";
    }

    public static GestorAutenticacion getInstancia() {
        if (instancia == null) {
            instancia = new GestorAutenticacion();
        }
        return instancia;
    }

    // Valida credenciales (usado en Login)
    public boolean validar(String usuario, String contrasena) {
        return this.usuarioValido.equals(usuario) && this.contrasenaValida.equals(contrasena);
    }
    
    // Valida solo contraseña (usado para autorizar cambios)
    public boolean verificarContrasenaActual(String pass) {
        return this.contrasenaValida.equals(pass);
    }

    // --- MÉTODOS SETTERS QUE TE FALTABAN ---
    // Estos permiten cambiar el usuario/clave de la sesión activa
    public void setUsuario(String nuevoUsuario) {
        this.usuarioValido = nuevoUsuario;
    }

    public void setContrasena(String nuevaContrasena) {
        this.contrasenaValida = nuevaContrasena;
    }
    
    public String getUsuarioActual() { return usuarioValido; }
}