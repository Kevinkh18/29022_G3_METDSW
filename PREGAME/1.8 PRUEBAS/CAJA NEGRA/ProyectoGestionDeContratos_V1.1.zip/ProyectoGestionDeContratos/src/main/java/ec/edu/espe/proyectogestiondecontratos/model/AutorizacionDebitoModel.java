package ec.edu.espe.proyectogestiondecontratos.model;

public class AutorizacionDebitoModel extends ContratoBase {

    // Hereda 'id' de ContratoBase.
    
    private String ciudad;
    private String fecha; // "15 de Agosto de 2025"
    private String nombre;
    private String tipoCuenta; // Ahorros / Corriente
    private String numeroCuenta;
    private String banco;
    private double montoMensual;
    private String cedula;

    public AutorizacionDebitoModel() {
    }

    // --- IMPLEMENTACIÓN DEL PADRE ---
    @Override
    public String getNombreCliente() {
        return this.nombre;
    }

    @Override
    public double getMontoTotal() {
        return this.montoMensual;
    }

    // --- GETTERS Y SETTERS ---
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(String tipoCuenta) { this.tipoCuenta = tipoCuenta; }

    public String getNumeroCuenta() { return numeroCuenta; }
    public void setNumeroCuenta(String numeroCuenta) { this.numeroCuenta = numeroCuenta; }

    public String getBanco() { return banco; }
    public void setBanco(String banco) { this.banco = banco; }

    public double getMontoMensual() { return montoMensual; }
    public void setMontoMensual(double montoMensual) { this.montoMensual = montoMensual; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }
}