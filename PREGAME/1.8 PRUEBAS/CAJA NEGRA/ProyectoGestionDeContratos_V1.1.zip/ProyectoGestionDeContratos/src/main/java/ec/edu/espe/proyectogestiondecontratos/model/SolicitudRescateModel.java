package ec.edu.espe.proyectogestiondecontratos.model;

public class SolicitudRescateModel extends ContratoBase {
    
    // --- 1. NUEVO ATRIBUTO ID ---
    private String id; 
    
    private String nombreBeneficiario;
    private String banco;
    private String numeroCuenta;
    private String tipoCuenta;
    private String cedula;
    private double valor;
    private String correo;

    public SolicitudRescateModel() {
    }

    // --- 2. NUEVOS MÉTODOS GETTER Y SETTER PARA ID ---
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
    // -------------------------------------------------

    public String getNombreBeneficiario() { return nombreBeneficiario; }
    public void setNombreBeneficiario(String nombreBeneficiario) { this.nombreBeneficiario = nombreBeneficiario; }

    public String getBanco() { return banco; }
    public void setBanco(String banco) { this.banco = banco; }

    public String getNumeroCuenta() { return numeroCuenta; }
    public void setNumeroCuenta(String numeroCuenta) { this.numeroCuenta = numeroCuenta; }

    public String getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(String tipoCuenta) { this.tipoCuenta = tipoCuenta; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public double getValor() { return valor; }
    public void setValor(double valor) { this.valor = valor; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
    
    
    @Override
    public String getNombreCliente() {
        return this.getNombreBeneficiario(); // Retorna tu variable existente
    }

    @Override
    public double getMontoTotal() {
        return this.getValor(); // Retorna tu variable existente
    }
}