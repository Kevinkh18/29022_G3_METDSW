package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.GestorContratos; 
import ec.edu.espe.proyectogestiondecontratos.model.SolicitudRescateGenericoModel;
import ec.edu.espe.proyectogestiondecontratos.utils.Validador;
import ec.edu.espe.proyectogestiondecontratos.view.SolicitudRescateGenericoView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

// CORRECCIÓN: Quitamos "extends ContratoBase". Un controlador no es un contrato.
public class SolicitudRescateGenericoController implements ActionListener {

    private SolicitudRescateGenericoView view;
    private SolicitudRescateGenericoModel model;
    private boolean esEdicion = false; 

    // =========================================================================
    // CONSTRUCTOR 1: CREAR NUEVO CONTRATO
    // =========================================================================
    public SolicitudRescateGenericoController(SolicitudRescateGenericoView view) {
        this.view = view;
        this.model = new SolicitudRescateGenericoModel();
        this.esEdicion = false;
        
        generarId();
        inicializar();
    }

    // =========================================================================
    // CONSTRUCTOR 2: EDITAR CONTRATO EXISTENTE
    // =========================================================================
    public SolicitudRescateGenericoController(SolicitudRescateGenericoView view, SolicitudRescateGenericoModel modeloExistente) {
        this.view = view;
        this.model = modeloExistente;
        this.esEdicion = true;
        
        // Llenamos la vista con los datos que ya tiene el modelo
        view.setId(model.getId());
        view.setCiudad(model.getCiudad());
        view.setFecha(model.getFecha());
        view.setMonto(String.valueOf(model.getMonto()));
        view.setBanco(model.getBanco());
        view.setNumeroCuenta(model.getNumeroCuenta());
        view.setTipoCuenta(model.getTipoCuenta());
        view.setNombre(model.getNombre());
        view.setCedula(model.getCedula());
        view.setCelular(model.getCelular());
        view.setCorreo(model.getCorreo());
        
        // Cambiamos el texto del botón para dar feedback visual
        view.getBtnGuardar().setText("Actualizar Datos");
        
        inicializar();
    }
    
    private void inicializar() {
        this.view.getBtnGuardar().addActionListener(this);
        this.view.getBtnCancelar().addActionListener(this);
    }

    private void generarId() {
        // Solo generamos ID si es NUEVO. Si editamos, mantenemos el ID original.
        if (!esEdicion) {
            int num = (int)(Math.random() * 90000) + 10000;
            String id = "SRE-" + num; // SRE = Solicitud Rescate Excel
            model.setId(id);
            view.setId(id);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnGuardar()) {
            guardar();
        } else if (e.getSource() == view.getBtnCancelar()) {
            view.cerrar();
        }
    }

    private void guardar() {
        // 1. Obtener datos
        String ciudad = view.getCiudad().trim();
        String montoStr = view.getMonto().trim();
        String banco = view.getBanco().trim();
        String cuenta = view.getNumeroCuenta().trim();
        String nombre = view.getNombre().trim();
        String cedula = view.getCedula().trim();
        String celular = view.getCelular().trim();
        String correo = view.getCorreo().trim();

        // 2. VALIDACIONES
        if (ciudad.isEmpty() || montoStr.isEmpty() || banco.isEmpty() || 
            nombre.isEmpty() || cedula.isEmpty()) {
            view.mostrarMensaje("Por favor complete los campos obligatorios.");
            return;
        }

        if (!Validador.esMontoValido(montoStr)) {
            view.mostrarMensaje("El monto debe ser un número válido positivo.");
            return;
        }

        if (!Validador.esSoloNumeros(cuenta)) {
            view.mostrarMensaje("La cuenta bancaria solo debe tener números.");
            return;
        }

        if (!Validador.esCedulaValida(cedula)) {
            view.mostrarMensaje("La cédula ingresada no es válida.");
            return;
        }

        if (!Validador.esCorreoValido(correo)) {
            view.mostrarMensaje("El formato del correo es incorrecto.");
            return;
        }

        if (!Validador.esSoloNumeros(celular) || celular.length() != 10) {
            view.mostrarMensaje("El celular debe tener 10 dígitos numéricos.");
            return;
        }

        // 3. GUARDAR / ACTUALIZAR
        try {
            model.setCiudad(ciudad);
            model.setFecha(view.getFecha());
            model.setMonto(Double.parseDouble(montoStr));
            model.setBanco(banco);
            model.setNumeroCuenta(cuenta);
            model.setTipoCuenta(view.getTipoCuenta());
            model.setNombre(nombre);
            model.setCedula(cedula);
            model.setCelular(celular);
            model.setCorreo(correo);

            if (esEdicion) {
                // Si es edición, el objeto ya está en memoria y modificado por referencia.
                view.mostrarMensaje("Trámite actualizado correctamente.");
            } else {
                // Si es nuevo, lo agregamos a la lista global
                GestorContratos.getInstancia().agregarContrato(model);
                view.mostrarMensaje("Solicitud " + model.getId() + " registrada correctamente.");
            }
            
            view.cerrar();

        } catch (Exception ex) {
            view.mostrarMensaje("Error al guardar: " + ex.getMessage());
        }
    }
}