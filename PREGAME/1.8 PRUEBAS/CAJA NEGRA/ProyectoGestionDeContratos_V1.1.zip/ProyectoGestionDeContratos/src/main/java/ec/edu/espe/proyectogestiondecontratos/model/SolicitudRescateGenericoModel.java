package ec.edu.espe.proyectogestiondecontratos.model;

// Asegúrate de que ContratoBase esté en el mismo paquete. 
// Si te marca error en "ContratoBase", verifica que el archivo ContratoBase.java exista y sea "public abstract class".

public class SolicitudRescateGenericoModel extends ContratoBase {

    // NOTA: Ya no ponemos 'id' aquí porque 'ContratoBase' ya lo tiene.
    
    private String ciudad;
    private String fecha; 
    private double monto;
    private String banco;
    private String numeroCuenta;
    private String tipoCuenta; // "Ahorros" o "Corriente"
    private String nombre;
    private String cedula;
    private String celular; 
    private String correo;

    public SolicitudRescateGenericoModel() {
        // Constructor vacío
    }

    // =========================================================
    // IMPLEMENTACIÓN OBLIGATORIA DEL PADRE (ContratoBase)
    // =========================================================
    @Override
    public String getNombreCliente() {
        return this.nombre;
    }

    @Override
    public double getMontoTotal() {
        return this.monto;
    }
    // =========================================================

    // GETTERS Y SETTERS (Solo de los campos propios)
    
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public double getMonto() { return monto; }
    public void setMonto(double monto) { this.monto = monto; }

    public String getBanco() { return banco; }
    public void setBanco(String banco) { this.banco = banco; }

    public String getNumeroCuenta() { return numeroCuenta; }
    public void setNumeroCuenta(String numeroCuenta) { this.numeroCuenta = numeroCuenta; }

    public String getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(String tipoCuenta) { this.tipoCuenta = tipoCuenta; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}