package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.GestorContratos;
import ec.edu.espe.proyectogestiondecontratos.model.SolicitudRescateModel;
// IMPORTA TU NUEVO VALIDADOR (Ajusta el paquete si es necesario)
import ec.edu.espe.proyectogestiondecontratos.utils.Validador; 
import ec.edu.espe.proyectogestiondecontratos.view.SolicitudRescateView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SolicitudRescateController implements ActionListener {

    private SolicitudRescateView view;
    private SolicitudRescateModel model;
    private boolean esEdicion = false;

    // ... (Tus constructores y métodos inicializar/generarIdUnico siguen igual) ...
    public SolicitudRescateController(SolicitudRescateView view) {
        this.view = view;
        this.model = new SolicitudRescateModel();
        this.esEdicion = false;
        generarIdUnico();
        inicializar();
    }

    public SolicitudRescateController(SolicitudRescateView view, SolicitudRescateModel modeloExistente) {
        this.view = view;
        this.model = modeloExistente;
        this.esEdicion = true;
        // ... (resto del código de llenado de vista igual) ...
        view.setId(model.getId());
        view.setNombre(model.getNombreBeneficiario());
        view.setBanco(model.getBanco());
        view.setCuenta(model.getNumeroCuenta());
        view.setTipoCuenta(model.getTipoCuenta());
        view.setCedula(model.getCedula());
        view.setValor(String.valueOf(model.getValor()));
        view.setCorreo(model.getCorreo());
        
        view.setTituloVentana("Editando Contrato: " + model.getId());
        view.getBtnGuardar().setText("Actualizar Datos");
        inicializar();
    }
    
    private void inicializar() {
        this.view.getBtnGuardar().addActionListener(this);
        this.view.getBtnCancelar().addActionListener(this);
    }
    
    private void generarIdUnico() {
        int numeroAleatorio = (int) (Math.random() * 900000) + 100000; 
        String idGenerado = "SRP-" + numeroAleatorio;
        model.setId(idGenerado);
        view.setId(idGenerado);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnGuardar()) {
            guardarDatos();
        } else if (e.getSource() == view.getBtnCancelar()) {
            view.cerrar();
        }
    }

    // =========================================================================
    // --- MÉTODO GUARDAR CON VALIDACIONES ROBUSTAS ---
    // =========================================================================
    private void guardarDatos() {
        // 1. Obtener datos crudos de la vista
        String nombre = view.getNombre().trim();
        String banco = view.getBanco().trim();
        String cuenta = view.getCuenta().trim();
        String cedula = view.getCedula().trim();
        String correo = view.getCorreo().trim();
        String valorStr = view.getValor().trim();

        // 2. VALIDACIÓN DE CAMPOS VACÍOS
        if (nombre.isEmpty() || banco.isEmpty() || cuenta.isEmpty() || 
            cedula.isEmpty() || correo.isEmpty() || valorStr.isEmpty()) {
            view.mostrarMensaje("Error: Todos los campos son obligatorios.");
            return; // Detiene el proceso
        }

        // 3. VALIDACIÓN DE CUENTA BANCARIA (Solo números)
        if (!Validador.esSoloNumeros(cuenta)) {
            view.mostrarMensaje("Error: El número de cuenta solo debe contener dígitos numéricos.");
            return;
        }

        // 4. VALIDACIÓN DE CÉDULA ECUATORIANA
        if (!Validador.esCedulaValida(cedula)) {
            view.mostrarMensaje("Error: La cédula ingresada NO es válida (formato ecuatoriano incorrecto).");
            return;
        }

        // 5. VALIDACIÓN DE CORREO ELECTRÓNICO
        if (!Validador.esCorreoValido(correo)) {
            view.mostrarMensaje("Error: El correo electrónico no tiene un formato válido (ej: usuario@dominio.com).");
            return;
        }

        // 6. VALIDACIÓN DE MONTO (Que sea número y positivo)
        if (!Validador.esMontoValido(valorStr)) {
            view.mostrarMensaje("Error: El valor a restituir debe ser un número positivo válido.");
            return;
        }

        // --- SI PASA TODAS LAS VALIDACIONES, RECIÉN GUARDAMOS ---
        try {
            model.setNombreBeneficiario(nombre);
            model.setBanco(banco);
            model.setNumeroCuenta(cuenta);
            model.setTipoCuenta(view.getTipoCuenta());
            model.setCedula(cedula);
            model.setCorreo(correo);
            model.setValor(Double.parseDouble(valorStr));

            if (esEdicion) {
                view.mostrarMensaje("Contrato actualizado exitosamente.");
            } else {
                GestorContratos.getInstancia().agregarContrato(model);
                view.mostrarMensaje("Contrato creado exitosamente con ID: " + model.getId());
            }
            
            view.cerrar();

        } catch (Exception ex) {
            view.mostrarMensaje("Ocurrió un error inesperado al guardar.");
            ex.printStackTrace();
        }
    }
}