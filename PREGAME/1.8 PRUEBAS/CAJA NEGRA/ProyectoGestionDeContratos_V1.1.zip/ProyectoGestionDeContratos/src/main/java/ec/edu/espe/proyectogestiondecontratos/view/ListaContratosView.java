package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class ListaContratosView extends JDialog {

    private JTable tablaContratos;
    private DefaultTableModel modeloTabla;
    private JButton btnCerrar;
    
    // --- COMPONENTES DE BÚSQUEDA ---
    private JComboBox<String> cmbFiltroTipo;
    private JButton btnFiltrarTipo; // Botón al lado del Combo
    
    private JTextField txtBuscarId;
    private JButton btnBuscarId;    // Botón al lado del ID

    public ListaContratosView(Frame owner) {
        super(owner, "Listado de Contratos", true);
        setSize(950, 500); // Un poco más ancho
        setLocationRelativeTo(owner);
        configurarComponentes();
    }

    private void configurarComponentes() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // --- PANEL DE BÚSQUEDA (FlowLayout alinea a la izquierda) ---
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 5)); // (Align, Hgap, Vgap)
        panelBusqueda.setBorder(BorderFactory.createTitledBorder("Herramientas de Búsqueda"));
        
        // GRUPO 1: FILTRO POR TIPO
        panelBusqueda.add(new JLabel("Tipo:"));
        cmbFiltroTipo = new JComboBox<>();
        cmbFiltroTipo.addItem("Todos");
        cmbFiltroTipo.addItem("Rescate Parcial (SRP)");
        cmbFiltroTipo.addItem("Solicitud Excel (SRE)");
        cmbFiltroTipo.addItem("Desvinculación Total (SDT)");
        cmbFiltroTipo.addItem("Débito Mensual (ADM)");
        panelBusqueda.add(cmbFiltroTipo);
        
        // Botón exclusivo para el filtro de tipo
        btnFiltrarTipo = new JButton("Filtrar");
        btnFiltrarTipo.setBackground(new Color(0, 123, 255)); // Azul
        btnFiltrarTipo.setForeground(Color.WHITE);
        panelBusqueda.add(btnFiltrarTipo);
        
        // Separador visual grande
        panelBusqueda.add(Box.createHorizontalStrut(30)); 

        // GRUPO 2: BÚSQUEDA POR ID
        panelBusqueda.add(new JLabel("ID Contrato:"));
        txtBuscarId = new JTextField(12);
        panelBusqueda.add(txtBuscarId);
        
        // Botón exclusivo para buscar ID
        btnBuscarId = new JButton("Buscar");
        btnBuscarId.setBackground(new Color(40, 167, 69)); // Verde (para diferenciar)
        btnBuscarId.setForeground(Color.WHITE);
        panelBusqueda.add(btnBuscarId);

        // Agregamos el panel arriba
        panel.add(panelBusqueda, BorderLayout.NORTH);

        // --- TABLA (Igual que antes) ---
        String[] columnas = {"ID Contrato", "Beneficiario", "Tipo de Contrato", "Monto ($)"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        
        tablaContratos = new JTable(modeloTabla);
        tablaContratos.setRowHeight(25);
        tablaContratos.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 12));
        
        // Configuración de celdas y click derecho
        tablaContratos.setCellSelectionEnabled(true); 
        tablaContratos.setRowSelectionAllowed(false);
        tablaContratos.setColumnSelectionAllowed(false);

        JPopupMenu menuTabla = new JPopupMenu();
        JMenuItem itemCopiar = new JMenuItem("Copiar dato");
        menuTabla.add(itemCopiar);
        itemCopiar.addActionListener(e -> {
            int fila = tablaContratos.getSelectedRow();
            int col = tablaContratos.getSelectedColumn();
            if (fila != -1 && col != -1) {
                Object valor = tablaContratos.getValueAt(fila, col);
                if (valor != null) {
                    java.awt.datatransfer.StringSelection seleccion = new java.awt.datatransfer.StringSelection(valor.toString());
                    java.awt.Toolkit.getDefaultToolkit().getSystemClipboard().setContents(seleccion, null);
                }
            }
        });
        tablaContratos.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mousePressed(java.awt.event.MouseEvent e) {
                if (SwingUtilities.isRightMouseButton(e)) {
                    int r = tablaContratos.rowAtPoint(e.getPoint());
                    int c = tablaContratos.columnAtPoint(e.getPoint());
                    if (r >= 0 && c >= 0) tablaContratos.changeSelection(r, c, false, false);
                }
            }
        });
        tablaContratos.setComponentPopupMenu(menuTabla);
        
        JScrollPane scrollPane = new JScrollPane(tablaContratos);
        panel.add(scrollPane, BorderLayout.CENTER);

        // Botón Cerrar
        btnCerrar = new JButton("Cerrar");
        JPanel panelBoton = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBoton.add(btnCerrar);
        panel.add(panelBoton, BorderLayout.SOUTH);

        add(panel);
    }

    // --- GETTERS ACTUALIZADOS ---
    public DefaultTableModel getModeloTabla() { return modeloTabla; }
    public JButton getBtnCerrar() { return btnCerrar; }
    
    // Getters Búsqueda
    public String getTextoBusqueda() { return txtBuscarId.getText(); }
    public String getTipoSeleccionado() { return (String) cmbFiltroTipo.getSelectedItem(); }
    
    // Getters de los NUEVOS botones
    public JButton getBtnFiltrarTipo() { return btnFiltrarTipo; }
    public JButton getBtnBuscarId() { return btnBuscarId; }
}