package ec.edu.espe.proyectogestiondecontratos.model;

public abstract class ContratoBase {
    protected String id;
    
    // Métodos abstractos que obligamos a los hijos a tener
    // Así la tabla siempre sabrá qué mostrar
    public abstract String getNombreCliente();
    public abstract double getMontoTotal();

    public String getId() { return id; }
    public void setId(String id) { this.id = id; }
}