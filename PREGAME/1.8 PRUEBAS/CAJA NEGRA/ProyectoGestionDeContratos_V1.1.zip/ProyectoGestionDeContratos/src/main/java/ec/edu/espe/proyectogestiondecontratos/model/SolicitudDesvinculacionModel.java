package ec.edu.espe.proyectogestiondecontratos.model;

public class SolicitudDesvinculacionModel extends ContratoBase {

    // Hereda 'id' de ContratoBase.
    // Usamos 'monto' para cumplir con el sistema, aunque el documento diga "Total".
    
    private String ciudad;
    private String fecha;
    private String banco;
    private String numeroCuenta;
    private String tipoCuenta;
    private String nombre;
    private String cedula;
    private String celular;
    private String correo;
    private double montoEstimado; // Dato interno para el sistema

    public SolicitudDesvinculacionModel() {
    }

    // --- IMPLEMENTACIÓN DEL PADRE ---
    @Override
    public String getNombreCliente() {
        return this.nombre;
    }

    @Override
    public double getMontoTotal() {
        return this.montoEstimado;
    }

    // --- GETTERS Y SETTERS PROPIOS ---
    public String getCiudad() { return ciudad; }
    public void setCiudad(String ciudad) { this.ciudad = ciudad; }

    public String getFecha() { return fecha; }
    public void setFecha(String fecha) { this.fecha = fecha; }

    public String getBanco() { return banco; }
    public void setBanco(String banco) { this.banco = banco; }

    public String getNumeroCuenta() { return numeroCuenta; }
    public void setNumeroCuenta(String numeroCuenta) { this.numeroCuenta = numeroCuenta; }

    public String getTipoCuenta() { return tipoCuenta; }
    public void setTipoCuenta(String tipoCuenta) { this.tipoCuenta = tipoCuenta; }

    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }

    public String getCedula() { return cedula; }
    public void setCedula(String cedula) { this.cedula = cedula; }

    public String getCelular() { return celular; }
    public void setCelular(String celular) { this.celular = celular; }

    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }

    public double getMontoEstimado() { return montoEstimado; }
    public void setMontoEstimado(double montoEstimado) { this.montoEstimado = montoEstimado; }
}