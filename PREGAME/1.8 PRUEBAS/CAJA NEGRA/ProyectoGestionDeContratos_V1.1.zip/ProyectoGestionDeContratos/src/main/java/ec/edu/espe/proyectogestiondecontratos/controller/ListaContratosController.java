package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.ContratoBase; 
import ec.edu.espe.proyectogestiondecontratos.model.GestorContratos;
import ec.edu.espe.proyectogestiondecontratos.view.ListaContratosView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JOptionPane;

public class ListaContratosController implements ActionListener {

    private ListaContratosView view;

    public ListaContratosController(ListaContratosView view) {
        this.view = view;
        // Carga inicial
        cargarDatosEnTabla(GestorContratos.getInstancia().getListaContratos());
        
        // Listeners
        this.view.getBtnCerrar().addActionListener(this);
        this.view.getBtnFiltrarTipo().addActionListener(this); 
        this.view.getBtnBuscarId().addActionListener(this);    
    }

    private void cargarDatosEnTabla(ArrayList<ContratoBase> lista) {
        view.getModeloTabla().setRowCount(0);
        
        for (ContratoBase c : lista) {
            Object[] fila = new Object[4];
            fila[0] = c.getId();
            fila[1] = c.getNombreCliente(); 
            
            String id = c.getId();
            if (id.startsWith("SRP")) fila[2] = "Rescate Parcial";
            else if (id.startsWith("SRE")) fila[2] = "Solicitud Excel";
            else if (id.startsWith("SDT")) fila[2] = "Desvinculación Total";
            else if (id.startsWith("ADM")) fila[2] = "Débito Mensual";
            else if (id.startsWith("CNF")) fila[2] = "Nuevo Fideicomiso";
            else fila[2] = "Otro";
            
            fila[3] = c.getMontoTotal(); 
            view.getModeloTabla().addRow(fila);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnCerrar()) {
            view.dispose();
        } 
        
        // --- CASO 1: CLICK EN "FILTRAR" ---
        // Solo usa el ComboBox. Ignora el texto del ID.
        else if (e.getSource() == view.getBtnFiltrarTipo()) {
            filtrarSoloPorCategoria();
        } 
        
        // --- CASO 2: CLICK EN "BUSCAR" ---
        // Usa el Texto ID Y TAMBIÉN respeta el ComboBox.
        else if (e.getSource() == view.getBtnBuscarId()) {
            buscarIdConFiltroDeCategoria();
        } 
    }
    
    // MÉTODO 1: FILTRAR (Ignora completamente el texto del ID)
    private void filtrarSoloPorCategoria() {
        String seleccion = view.getTipoSeleccionado(); 
        if (seleccion == null) return;

        ArrayList<ContratoBase> listaCompleta = GestorContratos.getInstancia().getListaContratos();
        ArrayList<ContratoBase> listaFiltrada = new ArrayList<>();

        for (ContratoBase c : listaCompleta) {
            // Solo verificamos si coincide el TIPO (ComboBox)
            // No leemos view.getTextoBusqueda() aquí.
            if (cumpleFiltroTipo(c, seleccion)) {
                listaFiltrada.add(c);
            }
        }
        
        cargarDatosEnTabla(listaFiltrada);
        if (listaFiltrada.isEmpty()) {
            JOptionPane.showMessageDialog(view, "No hay contratos de este tipo.");
        }
    }

    // MÉTODO 2: BUSCAR (Usa Texto + ComboBox)
    private void buscarIdConFiltroDeCategoria() {
        String textoId = view.getTextoBusqueda().trim().toUpperCase();
        String seleccion = view.getTipoSeleccionado(); 
        
        if (textoId.isEmpty()) {
            // Si la caja de texto está vacía, nos comportamos como el filtro normal
            filtrarSoloPorCategoria();
            return;
        }

        ArrayList<ContratoBase> listaCompleta = GestorContratos.getInstancia().getListaContratos();
        ArrayList<ContratoBase> listaFiltrada = new ArrayList<>();

        for (ContratoBase c : listaCompleta) {
            // 1. Verificamos Texto ID
            boolean coincideTexto = c.getId().toUpperCase().contains(textoId);
            
            // 2. Verificamos TIPO (ComboBox)
            boolean coincideTipo = cumpleFiltroTipo(c, seleccion);

            // Tienen que cumplirse LOS DOS
            if (coincideTexto && coincideTipo) {
                listaFiltrada.add(c);
            }
        }
        
        cargarDatosEnTabla(listaFiltrada);
        if (listaFiltrada.isEmpty()) {
            JOptionPane.showMessageDialog(view, "No se encontró ese ID en la categoría seleccionada.");
        }
    }
    
    // Auxiliar simple para validar tipos
    private boolean cumpleFiltroTipo(ContratoBase c, String seleccion) {
        String idActual = c.getId().toUpperCase();
        
        if (seleccion.equals("Todos")) return true;
        if (seleccion.contains("Rescate Parcial") && idActual.startsWith("SRP")) return true;
        if (seleccion.contains("Excel") && idActual.startsWith("SRE")) return true;
        if (seleccion.contains("Desvinculación") && idActual.startsWith("SDT")) return true;
        if (seleccion.contains("Débito") && idActual.startsWith("ADM")) return true;
        if (seleccion.contains("Nuevo Fideicomiso") && idActual.startsWith("CNF")) return true;
        
        return false;
    }
}