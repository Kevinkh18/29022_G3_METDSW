package ec.edu.espe.proyectogestiondecontratos.controller;

// --- IMPORTS OBLIGATORIOS ---
import ec.edu.espe.proyectogestiondecontratos.model.GestorContratos;
import ec.edu.espe.proyectogestiondecontratos.model.SolicitudDesvinculacionModel;
import ec.edu.espe.proyectogestiondecontratos.view.SolicitudDesvinculacionView;
import ec.edu.espe.proyectogestiondecontratos.utils.Validador; // <--- ASEGURATE DE TENER ESTA CLASE CREADA
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class SolicitudDesvinculacionController implements ActionListener {

    private SolicitudDesvinculacionView view;
    private SolicitudDesvinculacionModel model;
    private boolean esEdicion = false;

    // ==========================================================
    // CONSTRUCTOR 1: CREAR NUEVO
    // ==========================================================
    public SolicitudDesvinculacionController(SolicitudDesvinculacionView view) {
        this.view = view;
        this.model = new SolicitudDesvinculacionModel();
        this.esEdicion = false;
        
        generarId();
        inicializar();
    }

    // ==========================================================
    // CONSTRUCTOR 2: EDITAR EXISTENTE
    // ==========================================================
    public SolicitudDesvinculacionController(SolicitudDesvinculacionView view, SolicitudDesvinculacionModel modeloExistente) {
        this.view = view;
        this.model = modeloExistente;
        this.esEdicion = true;
        
        // Cargar datos a la vista
        view.setId(model.getId());
        view.setCiudad(model.getCiudad());
        view.setFecha(model.getFecha());
        view.setBanco(model.getBanco());
        view.setNumeroCuenta(model.getNumeroCuenta());
        view.setTipoCuenta(model.getTipoCuenta());
        view.setMonto(String.valueOf(model.getMontoEstimado()));
        view.setNombre(model.getNombre());
        view.setCedula(model.getCedula());
        view.setCelular(model.getCelular());
        view.setCorreo(model.getCorreo());
        
        view.getBtnGuardar().setText("Actualizar Trámite");
        inicializar();
    }

    private void inicializar() {
        this.view.getBtnGuardar().addActionListener(this);
        this.view.getBtnCancelar().addActionListener(this);
    }

    private void generarId() {
        if (!esEdicion) {
            int num = (int)(Math.random() * 90000) + 10000;
            String id = "SDT-" + num; // SDT = Solicitud Desvinculación Total
            model.setId(id);
            view.setId(id);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == view.getBtnGuardar()) {
            guardar();
        } else if (e.getSource() == view.getBtnCancelar()) {
            view.cerrar();
        }
    }

    private void guardar() {
        // Datos
        String banco = view.getBanco().trim();
        String cuenta = view.getNumeroCuenta().trim();
        String montoStr = view.getMonto().trim();
        String nombre = view.getNombre().trim();
        String cedula = view.getCedula().trim();
        String celular = view.getCelular().trim();
        String correo = view.getCorreo().trim();

        // Validaciones (Usando tu clase Validador)
        if (banco.isEmpty() || cuenta.isEmpty() || nombre.isEmpty() || cedula.isEmpty()) {
            view.mostrarMensaje("Complete los campos obligatorios.");
            return;
        }

        if (!Validador.esSoloNumeros(cuenta)) {
            view.mostrarMensaje("Número de cuenta inválido.");
            return;
        }
        if (!Validador.esCedulaValida(cedula)) {
            view.mostrarMensaje("Cédula inválida.");
            return;
        }
        if (!Validador.esCorreoValido(correo)) {
            view.mostrarMensaje("Correo inválido.");
            return;
        }
        if (!Validador.esMontoValido(montoStr)) {
            view.mostrarMensaje("El monto estimado debe ser un número válido.");
            return;
        }

        // Advertencia extra por ser desvinculación
        if (!esEdicion) {
            int confirm = JOptionPane.showConfirmDialog(view, 
                "¿Está seguro de procesar una DESVINCULACIÓN TOTAL?\nEsto cerrará la cuenta del cliente.",
                "Confirmación de Cierre", JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (confirm != JOptionPane.YES_OPTION) return;
        }

        // Guardar en modelo
        try {
            model.setCiudad(view.getCiudad());
            model.setFecha(view.getFecha());
            model.setBanco(banco);
            model.setNumeroCuenta(cuenta);
            model.setTipoCuenta(view.getTipoCuenta());
            model.setMontoEstimado(Double.parseDouble(montoStr));
            model.setNombre(nombre);
            model.setCedula(cedula);
            model.setCelular(celular);
            model.setCorreo(correo);

            if (!esEdicion) {
                GestorContratos.getInstancia().agregarContrato(model);
            }
            
            view.mostrarMensaje("Solicitud de Desvinculación guardada exitosamente.");
            view.cerrar();
            
        } catch (Exception ex) {
            view.mostrarMensaje("Error al guardar: " + ex.getMessage());
        }
    }
}