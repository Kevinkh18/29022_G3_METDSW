package ec.edu.espe.proyectogestiondecontratos.model;

public class Usuario {
    private String nombre;
    private String contrasena;

    public Usuario(String nombre, String contrasena) {
        this.nombre = nombre;
        this.contrasena = contrasena;
    }

    // Getters y Setters
    public String getNombre() { return nombre; }
    public String getContrasena() { return contrasena; }

    // En un futuro, aquí podrías tener métodos como 'guardarEnBD()'
    
    
}