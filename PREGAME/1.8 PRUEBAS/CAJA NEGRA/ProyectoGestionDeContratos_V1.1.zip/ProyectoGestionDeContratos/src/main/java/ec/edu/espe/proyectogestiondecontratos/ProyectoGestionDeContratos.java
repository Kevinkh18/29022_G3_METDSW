/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ec.edu.espe.proyectogestiondecontratos;

import ec.edu.espe.proyectogestiondecontratos.controller.LoginController;
import ec.edu.espe.proyectogestiondecontratos.view.LoginView;
import javax.swing.SwingUtilities;

/**
 *
 * @author LABS-ESPE
 */
public class ProyectoGestionDeContratos {

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginView vista = new LoginView();
            LoginController controlador = new LoginController(vista);
            vista.setVisible(true);
        });
    }
}
