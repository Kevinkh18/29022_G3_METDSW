package ec.edu.espe.proyectogestiondecontratos.model;

import java.util.ArrayList;

public class GestorContratos {
    
    private static GestorContratos instancia;
    
    // CAMBIO CLAVE: Ahora es una lista de ContratoBase (el padre)
    private ArrayList<ContratoBase> listaContratos;

    private GestorContratos() {
        listaContratos = new ArrayList<>();
    }

    public static GestorContratos getInstancia() {
        if (instancia == null) {
            instancia = new GestorContratos();
        }
        return instancia;
    }

    // Aceptamos cualquier hijo de ContratoBase
    public void agregarContrato(ContratoBase contrato) {
        listaContratos.add(contrato);
    }

    public ArrayList<ContratoBase> getListaContratos() {
        return listaContratos;
    }
    
    // Buscamos por ID genérico
    public ContratoBase buscarContrato(String id) {
        for (ContratoBase contrato : listaContratos) {
            if (contrato.getId().equalsIgnoreCase(id)) {
                return contrato;
            }
        }
        return null;
    }

    public boolean eliminarContrato(String id) {
        ContratoBase contrato = buscarContrato(id);
        if (contrato != null) {
            listaContratos.remove(contrato);
            return true;
        }
        return false;
    }
}