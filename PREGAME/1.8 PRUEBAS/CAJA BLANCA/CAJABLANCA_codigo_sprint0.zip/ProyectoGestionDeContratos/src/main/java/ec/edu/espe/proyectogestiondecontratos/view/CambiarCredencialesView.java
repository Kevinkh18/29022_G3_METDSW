package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import java.awt.*;

public class CambiarCredencialesView extends JDialog {
    
    private JTextField txtNuevoUsuario;
    private JTextField txtNuevaContrasena;
    private JButton btnGuardar;

    public CambiarCredencialesView(Frame owner) {
        super(owner, "Actualizar Credenciales", true); // true = Modal (bloquea la ventana de atrás)
        setSize(300, 200);
        setLocationRelativeTo(owner);
        setLayout(new GridLayout(3, 2, 10, 10));
        
        add(new JLabel("  Nuevo Usuario:"));
        txtNuevoUsuario = new JTextField();
        add(txtNuevoUsuario);
        
        add(new JLabel("  Nueva Contraseña:"));
        txtNuevaContrasena = new JTextField();
        add(txtNuevaContrasena);
        
        btnGuardar = new JButton("Guardar Cambios");
        add(new JLabel("")); // Relleno
        add(btnGuardar);
    }

    public String getNuevoUsuario() { return txtNuevoUsuario.getText(); }
    public String getNuevaContrasena() { return txtNuevaContrasena.getText(); }
    public JButton getBtnGuardar() { return btnGuardar; }
}