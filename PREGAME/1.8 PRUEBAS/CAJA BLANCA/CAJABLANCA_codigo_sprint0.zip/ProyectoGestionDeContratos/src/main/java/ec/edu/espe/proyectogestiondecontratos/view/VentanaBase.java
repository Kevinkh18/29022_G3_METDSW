package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.JFrame;
import javax.swing.WindowConstants;
import java.awt.Dimension;
import java.awt.Toolkit;

public abstract class VentanaBase extends JFrame {

    public VentanaBase(String titulo) {
        super(titulo);
        // Configuración estándar para todas las ventanas
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setResizable(false);
        setSize(new Dimension(400, 300)); // Tamaño compacto y fijo
        centrarVentana();
    }

    private void centrarVentana() {
        Dimension pantalla = Toolkit.getDefaultToolkit().getScreenSize();
        int x = (pantalla.width - getWidth()) / 2;
        int y = (pantalla.height - getHeight()) / 2;
        setLocation(x, y);
    }

    // Método abstracto que obliga a las subclases a implementar la configuración de sus componentes
    protected abstract void configurarComponentes();
}