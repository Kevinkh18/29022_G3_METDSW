package ec.edu.espe.proyectogestiondecontratos.view;

import javax.swing.*;
import java.awt.*;
import java.net.URL; // Necesario para cargar recursos
import java.io.InputStream; // Necesario para cargar el logo como stream de bytes

public class LoginView extends VentanaBase {

    // 1. Componentes de la vista
    private JTextField txtUsuario;
    private JPasswordField txtContrasena;
    private JButton btnLogin;

    public LoginView() {
        super("Inicio de Sesión - Sistema");
        configurarComponentes();
    }

    @Override
    protected void configurarComponentes() {
        // 2. Panel principal y Layout (Diseño Compacto y Moderno)
        JPanel panelPrincipal = new JPanel(new GridBagLayout());
        panelPrincipal.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // Padding
        panelPrincipal.setBackground(new Color(240, 240, 240)); // Un color de fondo suave

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(8, 8, 8, 8); // Espacio entre componentes
        gbc.fill = GridBagConstraints.HORIZONTAL;

        // =========================================================
        // AÑADIR EL LOGO
        // =========================================================
        JLabel lblLogo = new JLabel();
        
        // 🚨 SOLUCIÓN FINAL: Carga como Stream (la más robusta) 🚨
        // Usando la ruta simple "logo_empresa.png" ya que está en el mismo paquete.
        
        try (InputStream is = getClass().getResourceAsStream("/ec/edu/espe/proyectogestiondecontratos/view/logo_empresa.png")) {
            
            if (is != null) {
                // Lee los bytes del stream y crea el ImageIcon
                byte[] bytes = is.readAllBytes();
                ImageIcon iconoOriginal = new ImageIcon(bytes);

                // Redimensionar el logo (ejemplo a 100x100)
                Image imagen = iconoOriginal.getImage();
                Image imagenRedimensionada = imagen.getScaledInstance(100, 100, Image.SCALE_SMOOTH); 
                lblLogo.setIcon(new ImageIcon(imagenRedimensionada));
            } else {
                lblLogo.setText(" LOGO NO ENCONTRADO (Ruta final fallida) "); 
                lblLogo.setFont(new Font("Segoe UI", Font.ITALIC, 10));
            }

        } catch (java.io.IOException e) {
            lblLogo.setText("Error de E/S al cargar logo.");
            System.err.println("Error al cargar el logo: " + e.getMessage());
        }

        lblLogo.setHorizontalAlignment(SwingConstants.CENTER);
        
        // Posicionamiento del logo: Fila 0
        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2; // Ocupa las dos columnas
        gbc.insets = new Insets(0, 8, 15, 8); // Ajustamos el padding para separarlo del título
        panelPrincipal.add(lblLogo, gbc);


        // =========================================================
        // COMPONENTES EXISTENTES (AJUSTANDO FILAS)
        // =========================================================
        
        // --- Título (Ahora en Fila 1) ---
        JLabel lblTitulo = new JLabel("ACCESO AL SISTEMA");
        lblTitulo.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitulo.setHorizontalAlignment(SwingConstants.CENTER);
        
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        gbc.insets = new Insets(8, 8, 8, 8); // Restauramos el padding
        panelPrincipal.add(lblTitulo, gbc);

        // --- Campo Usuario (Ahora en Fila 2) ---
        txtUsuario = new JTextField(15);
        txtUsuario.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150), 1, true)); // Borde suave
        
        gbc.gridwidth = 1; // Volver a una columna
        gbc.gridx = 0; gbc.gridy = 2;
        panelPrincipal.add(new JLabel("Usuario:"), gbc);
        gbc.gridx = 1; gbc.gridy = 2;
        panelPrincipal.add(txtUsuario, gbc);

        // --- Campo Contraseña (Ahora en Fila 3) ---
        txtContrasena = new JPasswordField(15);
        txtContrasena.setBorder(BorderFactory.createLineBorder(new Color(150, 150, 150), 1, true));

        gbc.gridx = 0; gbc.gridy = 3;
        panelPrincipal.add(new JLabel("Contraseña:"), gbc);
        gbc.gridx = 1; gbc.gridy = 3;
        panelPrincipal.add(txtContrasena, gbc);

        // --- Botón de Login (Ahora en Fila 4) ---
        btnLogin = new JButton("Iniciar Sesión");
        btnLogin.setBackground(new Color(0, 123, 255)); // Azul moderno
        btnLogin.setForeground(Color.WHITE);
        btnLogin.setFocusPainted(false);
        btnLogin.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0)); // Padding en el botón
        
        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        gbc.insets = new Insets(20, 8, 8, 8); // Más espacio encima del botón
        panelPrincipal.add(btnLogin, gbc);

        add(panelPrincipal, BorderLayout.CENTER);
        pack(); // Ajusta el tamaño de la ventana al nuevo contenido (Importante)
    }

    // 3. Métodos para que el controlador acceda a los datos y eventos
    public String getUsuario() {
        return txtUsuario.getText();
    }

    public String getContrasena() {
        return new String(txtContrasena.getPassword());
    }

    public void agregarLoginListener(java.awt.event.ActionListener listener) {
        btnLogin.addActionListener(listener);
    }
    
    public void mostrarMensaje(String mensaje, String titulo, int tipo) {
        JOptionPane.showMessageDialog(this, mensaje, titulo, tipo);
    }
    public void limpiarCampos() {
    txtUsuario.setText("");
    txtContrasena.setText("");
}
    
}