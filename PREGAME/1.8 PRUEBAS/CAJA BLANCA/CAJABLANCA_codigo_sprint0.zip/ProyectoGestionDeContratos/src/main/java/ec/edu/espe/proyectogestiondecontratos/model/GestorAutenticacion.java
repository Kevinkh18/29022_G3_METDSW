package ec.edu.espe.proyectogestiondecontratos.model;

/**
 * Singleton para manejar las credenciales actuales del sistema.
 * Permite que diferentes controladores accedan y modifiquen los mismos datos.
 */
public class GestorAutenticacion {
    
    private static GestorAutenticacion instancia;
    
    private String usuarioValido;
    private String contrasenaValida;

    private GestorAutenticacion() {
        // Inicializamos con los valores por defecto
        this.usuarioValido = "admin";
        this.contrasenaValida = "12345";
    }

    public static GestorAutenticacion getInstancia() {
        if (instancia == null) {
            instancia = new GestorAutenticacion();
        }
        return instancia;
    }

    public boolean validar(String usuario, String contrasena) {
        return this.usuarioValido.equals(usuario) && this.contrasenaValida.equals(contrasena);
    }

    public void actualizarCredenciales(String nuevoUsuario, String nuevaContrasena) {
        this.usuarioValido = nuevoUsuario;
        this.contrasenaValida = nuevaContrasena;
    }
    
    // Getters para mostrar info actual si se desea
    public String getUsuarioActual() { return usuarioValido; }
}