package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.GestorAutenticacion; // IMPORTANTE
import ec.edu.espe.proyectogestiondecontratos.view.DashboardView;       // IMPORTANTE
import ec.edu.espe.proyectogestiondecontratos.view.LoginView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import java.util.concurrent.TimeUnit;

public class LoginController implements ActionListener {

    private LoginView vista;
    
    // YA NO USAMOS CONSTANTES LOCALES, USAMOS EL MODELO
    // private final String USUARIO_VALIDO = "admin";  <-- ELIMINAR O COMENTAR
    // private final String CONTRASENA_VALIDA = "12345"; <-- ELIMINAR O COMENTAR

    // --- Variables de Seguridad ---
    private static final int MAX_INTENTOS = 3;
    private static final long TIEMPO_BLOQUEO_SEGUNDOS = 30;
    
    private int intentosFallidos = 0;
    private long tiempoBloqueoHasta = 0;

    public LoginController(LoginView vista) {
        this.vista = vista;
        this.vista.agregarLoginListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (estaBloqueado()) {
            manejarBloqueo();
            return;
        }
        
        String usuario = vista.getUsuario();
        String contrasena = vista.getContrasena();

        if (validarCredenciales(usuario, contrasena)) {
            intentosFallidos = 0;
            tiempoBloqueoHasta = 0;
            
            vista.mostrarMensaje("¡Bienvenido!", "Inicio Exitoso", JOptionPane.INFORMATION_MESSAGE);
            
            // --- CAMBIO PRINCIPAL AQUÍ ---
            // 1. Cerrar Login
            vista.dispose(); 
            
            // 2. Abrir Dashboard (Principio de Responsabilidad Única: delegamos al nuevo controlador)
            DashboardView dashboardView = new DashboardView();
            new DashboardController(dashboardView); // Inicia el controlador del dashboard
            dashboardView.setVisible(true);
            // -----------------------------
            
        } else {
            intentosFallidos++;
            vista.mostrarMensaje("Usuario o Contraseña incorrectos. Intento: " + intentosFallidos,
                                 "Error de Login", JOptionPane.ERROR_MESSAGE);

            if (intentosFallidos >= MAX_INTENTOS) {
                activarBloqueo();
                manejarBloqueo();
            }
        }
    }
    
    private boolean validarCredenciales(String usuario, String contrasena) {
        // AHORA USAMOS EL GESTOR DE AUTENTICACIÓN
        return GestorAutenticacion.getInstancia().validar(usuario, contrasena);
    }
    
    // ... (El resto de métodos private de bloqueo se mantienen igual) ...
    private boolean estaBloqueado() {
        return System.currentTimeMillis() < tiempoBloqueoHasta;
    }
    
    private void activarBloqueo() {
        long tiempoBloqueoMilis = TimeUnit.SECONDS.toMillis(TIEMPO_BLOQUEO_SEGUNDOS);
        tiempoBloqueoHasta = System.currentTimeMillis() + tiempoBloqueoMilis;
    }
    
    private void manejarBloqueo() {
        long tiempoRestante = (tiempoBloqueoHasta - System.currentTimeMillis()) / 1000;
        vista.mostrarMensaje("Cuenta bloqueada. Espere " + tiempoRestante + "s.", "Cuenta Bloqueada", JOptionPane.WARNING_MESSAGE);
    }
}