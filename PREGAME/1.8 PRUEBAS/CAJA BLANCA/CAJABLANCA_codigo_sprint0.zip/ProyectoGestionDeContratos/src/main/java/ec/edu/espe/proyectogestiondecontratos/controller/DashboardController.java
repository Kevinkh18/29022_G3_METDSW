package ec.edu.espe.proyectogestiondecontratos.controller;

import ec.edu.espe.proyectogestiondecontratos.model.GestorAutenticacion;
import ec.edu.espe.proyectogestiondecontratos.view.CambiarCredencialesView;
import ec.edu.espe.proyectogestiondecontratos.view.DashboardView;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;

public class DashboardController implements ActionListener {

    private DashboardView view;

    public DashboardController(DashboardView view) {
        this.view = view;
        inicializarVista();
    }
    
    private void inicializarVista() {
        // Enlazar los listeners a todos los botones
        this.view.getBtnCrear().addActionListener(this);
        this.view.getBtnLeer().addActionListener(this);
        this.view.getBtnActualizar().addActionListener(this);
        this.view.getBtnEliminar().addActionListener(this);
        this.view.getBtnCambiarCredenciales().addActionListener(this);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        
        // 1. Lógica para el botón de CREAR
        if (e.getSource() == view.getBtnCrear()) {
            // AQUÍ ABRIRÍAS LA VENTANA DE REGISTRO
            JOptionPane.showMessageDialog(view, "Abriendo formulario para Registrar Fideicomiso...", 
                    "Crear", JOptionPane.INFORMATION_MESSAGE);
            // Ejemplo: new FideicomisoController(new FrmFideicomiso()).iniciar();
        } 
        
        // 2. Lógica para el botón de LEER/BUSCAR
        else if (e.getSource() == view.getBtnLeer()) {
            JOptionPane.showMessageDialog(view, "Mostrando lista de contratos existentes...", 
                    "Ver Contratos", JOptionPane.INFORMATION_MESSAGE);
        }
        
        // 3. Lógica para el botón de ACTUALIZAR
        else if (e.getSource() == view.getBtnActualizar()) {
            JOptionPane.showMessageDialog(view, "Seleccione un contrato para editar.", 
                    "Modificar", JOptionPane.WARNING_MESSAGE);
        }
        
        // 4. Lógica para el botón de ELIMINAR
        else if (e.getSource() == view.getBtnEliminar()) {
            int confirm = JOptionPane.showConfirmDialog(view, "¿Está seguro de entrar al módulo de eliminación?",
                    "Dar de Baja", JOptionPane.YES_NO_OPTION);
            if(confirm == JOptionPane.YES_OPTION) {
                 System.out.println("Acceso a módulo de eliminación concedido.");
            }
        }
        
        // 5. Lógica existente para CAMBIAR CREDENCIALES
        else if (e.getSource() == view.getBtnCambiarCredenciales()) {
            abrirCambioCredenciales();
        }
    }
    
    private void abrirCambioCredenciales() {
        CambiarCredencialesView dialog = new CambiarCredencialesView(view);
        
        dialog.getBtnGuardar().addActionListener(evt -> {
            String user = dialog.getNuevoUsuario();
            String pass = dialog.getNuevaContrasena();
            
            if(!user.isEmpty() && !pass.isEmpty()) {
                GestorAutenticacion.getInstancia().actualizarCredenciales(user, pass);
                JOptionPane.showMessageDialog(dialog, "Credenciales actualizadas correctamente.");
                dialog.dispose();
            } else {
                JOptionPane.showMessageDialog(dialog, "Los campos no pueden estar vacíos.");
            }
        });
        
        dialog.setVisible(true);
    }
}